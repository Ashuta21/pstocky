import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, FontSize, Radius } from '@/constants/theme';

type BadgeVariant = 'success' | 'warning' | 'danger' | 'primary' | 'secondary' | 'neutral';

interface BadgeProps {
  label: string;
  variant?: BadgeVariant;
}

const variantColors: Record<BadgeVariant, { bg: string; text: string }> = {
  success: { bg: '#D1FAE5', text: Colors.success },
  warning: { bg: '#FEF3C7', text: Colors.warning },
  danger: { bg: '#FEE2E2', text: Colors.danger },
  primary: { bg: '#DBEAFE', text: Colors.primary },
  secondary: { bg: '#EDE9FE', text: Colors.secondary },
  neutral: { bg: '#F1F5F9', text: '#64748B' },
};

export function Badge({ label, variant = 'neutral' }: BadgeProps) {
  const c = variantColors[variant];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Text style={[styles.text, { color: c.text }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: FontSize.xs,
    fontWeight: '600',
  },
});
