import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Radius, Spacing, FontSize } from '@/constants/theme';

type Variant = 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost' | 'success';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: Variant;
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
}

const variantConfig = {
  primary: { gradient: [Colors.primary, '#2563EB'] as [string, string], text: '#fff', border: 'transparent' },
  secondary: { gradient: [Colors.secondary, '#7C3AED'] as [string, string], text: '#fff', border: 'transparent' },
  danger: { gradient: [Colors.danger, '#DC2626'] as [string, string], text: '#fff', border: 'transparent' },
  success: { gradient: [Colors.success, '#059669'] as [string, string], text: '#fff', border: 'transparent' },
  outline: { gradient: null, text: Colors.primary, border: Colors.primary },
  ghost: { gradient: null, text: Colors.primary, border: 'transparent' },
};

const sizeConfig = {
  sm: { height: 36, fontSize: FontSize.sm, paddingH: Spacing.md },
  md: { height: 48, fontSize: FontSize.md, paddingH: Spacing.lg },
  lg: { height: 56, fontSize: FontSize.lg, paddingH: Spacing.xl },
};

export function Button({
  title,
  onPress,
  variant = 'primary',
  loading = false,
  disabled = false,
  style,
  textStyle,
  size = 'md',
  icon,
}: ButtonProps) {
  const cfg = variantConfig[variant];
  const sz = sizeConfig[size];
  const opacity = disabled || loading ? 0.6 : 1;

  const inner = (
    <>
      {loading ? (
        <ActivityIndicator color={cfg.text} size="small" />
      ) : (
        <>
          {icon}
          <Text
            style={[
              styles.text,
              { color: cfg.text, fontSize: sz.fontSize, marginLeft: icon ? 8 : 0 },
              textStyle,
            ]}
          >
            {title}
          </Text>
        </>
      )}
    </>
  );

  if (cfg.gradient) {
    return (
      <TouchableOpacity
        onPress={onPress}
        disabled={disabled || loading}
        activeOpacity={0.85}
        style={[{ opacity, borderRadius: Radius.md }, style]}
      >
        <LinearGradient
          colors={cfg.gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.base, { height: sz.height, paddingHorizontal: sz.paddingH }]}
        >
          {inner}
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.85}
      style={[
        styles.base,
        {
          height: sz.height,
          paddingHorizontal: sz.paddingH,
          borderWidth: cfg.border !== 'transparent' ? 1.5 : 0,
          borderColor: cfg.border,
          opacity,
          borderRadius: Radius.md,
        },
        style,
      ]}
    >
      {inner}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: Radius.md,
  },
  text: {
    fontWeight: '600',
  },
});
