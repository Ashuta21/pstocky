import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Spacing } from '@/constants/theme';

interface SimpleBarChartProps {
  data: { label: string; value: number }[];
  color?: string;
  title?: string;
  height?: number;
}

const { width: SCREEN_W } = Dimensions.get('window');

export function SimpleBarChart({ data, color = Colors.primary, title, height = 160 }: SimpleBarChartProps) {
  const { colors } = useTheme();
  const max = Math.max(...data.map((d) => d.value), 1);

  return (
    <View>
      {title && (
        <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
      )}
      <View style={[styles.container, { height }]}>
        {data.map((item, i) => (
          <View key={i} style={styles.barGroup}>
            <View style={[styles.barBg, { height: height - 32 }]}>
              <View
                style={[
                  styles.bar,
                  {
                    height: ((item.value / max) * (height - 32)),
                    backgroundColor: color,
                  },
                ]}
              />
            </View>
            <Text style={[styles.label, { color: colors.textSecondary }]} numberOfLines={1}>
              {item.label}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: FontSize.md, fontWeight: '600', marginBottom: Spacing.sm },
  container: { flexDirection: 'row', alignItems: 'flex-end' },
  barGroup: { flex: 1, alignItems: 'center' },
  barBg: {
    width: '70%',
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(59,130,246,0.08)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  bar: { width: '100%', borderRadius: 4 },
  label: { fontSize: 10, marginTop: 4 },
});
