import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '@/hooks/useTheme';
import { FontSize, Radius, Spacing } from '@/constants/theme';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  gradient: [string, string];
  subtitle?: string;
  trend?: number;
}

export function StatCard({ title, value, icon, gradient, subtitle, trend }: StatCardProps) {
  const { colors } = useTheme();
  return (
    <LinearGradient
      colors={gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.card}
    >
      <View style={styles.iconWrap}>{icon}</View>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.title}>{title}</Text>
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
      {trend !== undefined && (
        <Text style={[styles.trend, { color: trend >= 0 ? '#86EFAC' : '#FCA5A5' }]}>
          {trend >= 0 ? '+' : ''}{trend}%
        </Text>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: Radius.lg,
    padding: Spacing.md,
    minHeight: 120,
    justifyContent: 'space-between',
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  value: {
    fontSize: FontSize.xxl,
    fontWeight: '700',
    color: '#fff',
  },
  title: {
    fontSize: FontSize.sm,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '500',
  },
  subtitle: {
    fontSize: FontSize.xs,
    color: 'rgba(255,255,255,0.65)',
  },
  trend: {
    fontSize: FontSize.sm,
    fontWeight: '600',
    marginTop: 4,
  },
});
