# PStocky - Android APK Build Guide

## Package: com.pstocky.app | Version: 1.0.0 | Min SDK: Android 8.0 (API 26)

---

## Prerequisites

Install the EAS CLI globally on your local machine:

```bash
npm install -g eas-cli
```

---

## Step 1 — Create an Expo Account

Sign up free at https://expo.dev and log in:

```bash
eas login
```

---

## Step 2 — Link the project to EAS

Run once in the project directory:

```bash
eas init
```

This creates a project on expo.dev and writes the `projectId` into `app.json` → `extra.eas.projectId`.

---

## Step 3 — Configure your API URL

Edit `config/api.ts` and set your real backend URL:

```ts
BASE_URL: 'https://yourdomain.com/api',
```

---

## Step 4 — Configure Firebase (optional, for push notifications)

1. Go to https://console.firebase.google.com
2. Create a project named **pstocky-app**
3. Add an Android app with package name `com.pstocky.app`
4. Download `google-services.json` and replace the placeholder at the project root

---

## Step 5 — Generate a Keystore (for signing)

EAS manages keystores automatically. On first build it will ask to generate one.
To use your own:

```bash
eas credentials
```

Select **Android → production → Keystore** and follow the prompts.

---

## Step 6 — Build the APK (direct install / sideloading)

```bash
npm run build:android:apk
# or directly:
eas build --platform android --profile apk
```

EAS builds in the cloud (~10-15 min). When complete you get a **download URL** for the `.apk` file.

---

## Step 7 — Build for Google Play Store (AAB)

```bash
npm run build:android:production
# or:
eas build --platform android --profile production
```

This produces a `.aab` bundle optimized for the Play Store.

---

## Step 8 — Submit to Google Play (optional)

```bash
npm run submit:android
```

Requires a Google Play service account JSON at `./google-play-service-account.json`.

---

## Build Profiles Summary

| Profile       | Output | Use case                        |
|---------------|--------|---------------------------------|
| `development` | APK    | Dev client with hot reload      |
| `preview`     | APK    | Internal testing / QA           |
| `apk`         | APK    | Direct install / sideloading    |
| `production`  | AAB    | Google Play Store submission    |

---

## Android Permissions Configured

- `CAMERA` — barcode & QR scanning
- `USE_BIOMETRIC` / `USE_FINGERPRINT` — fingerprint login
- `POST_NOTIFICATIONS` — push notifications
- `INTERNET` / `ACCESS_NETWORK_STATE` — API calls
- `READ_MEDIA_IMAGES` — product image upload
- `WRITE_EXTERNAL_STORAGE` — PDF/Excel export (Android 8)
- `VIBRATE` — haptic feedback
- `RECEIVE_BOOT_COMPLETED` — background notification delivery
- `FLASHLIGHT` — torch for barcode scanning

---

## App Icon & Splash Screen

Replace these files with your branded assets before building:

| File | Size | Purpose |
|------|------|---------|
| `assets/images/icon.png` | 1024×1024 px | App icon (all platforms) |
| `assets/images/adaptive-icon.png` | 1024×1024 px | Android adaptive icon foreground |
| `assets/images/splash.png` | 1284×2778 px | Splash screen image |

Adaptive icon background color is `#0F172A` (dark navy) — set in `app.json`.

---

## Troubleshooting

**"eas: command not found"** → Run `npm install -g eas-cli`

**"Missing projectId"** → Run `eas init` to link the project

**Build fails on google-services.json** → Either set up Firebase or remove the
`"googleServicesFile"` key from `app.json` android section if you don't need FCM

**Keystore issues** → Run `eas credentials` to manage signing keys
