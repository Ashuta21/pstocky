import { useAppStore } from '@/store';
import { Colors } from '@/constants/theme';
import { t, TranslationKey } from '@/constants/i18n';

export function useTheme() {
  const { theme, language } = useAppStore();
  const isDark = theme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const translate = (key: TranslationKey) => t(key, language);

  return { isDark, colors, theme, language, t: translate, Colors };
}
