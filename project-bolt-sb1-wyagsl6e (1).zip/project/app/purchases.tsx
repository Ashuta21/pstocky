import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, X, ShoppingBag, ChevronRight } from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const DEMO_PURCHASES = [
  { id: 1, po: 'PO-2025-001', supplier: 'Ethio Electronics PLC', date: '2025-06-01', total: 60000, status: 'received', items: 5 },
  { id: 2, po: 'PO-2025-002', supplier: 'Fasika Trading', date: '2025-05-25', total: 22000, status: 'pending', items: 3 },
  { id: 3, po: 'PO-2025-003', supplier: 'Abay Imports', date: '2025-05-20', total: 45000, status: 'received', items: 8 },
  { id: 4, po: 'PO-2025-004', supplier: 'Ethio Electronics PLC', date: '2025-05-10', total: 30000, status: 'partial', items: 4 },
];

const statusVariant: Record<string, any> = {
  received: 'success',
  pending: 'warning',
  partial: 'primary',
};

export default function PurchasesScreen() {
  const { colors, t } = useTheme();
  const [purchases] = useState(DEMO_PURCHASES);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ supplier: '', items: '', total: '', note: '' });
  const [selected, setSelected] = useState<typeof DEMO_PURCHASES[0] | null>(null);
  const [showDetail, setShowDetail] = useState(false);

  const handleSave = () => {
    if (!form.supplier) { Alert.alert('Error', 'Supplier is required'); return; }
    Alert.alert('Success', 'Purchase order created');
    setShowForm(false);
    setForm({ supplier: '', items: '', total: '', note: '' });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader
        title={t('purchases')}
        showBack
        right={
          <TouchableOpacity
            onPress={() => setShowForm(true)}
            style={[styles.addBtn, { backgroundColor: Colors.primary }]}
          >
            <Plus size={18} color="#fff" />
          </TouchableOpacity>
        }
      />

      <FlatList
        data={purchases}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.row, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => { setSelected(item); setShowDetail(true); }}
          >
            <View style={[styles.icon, { backgroundColor: Colors.secondary + '18' }]}>
              <ShoppingBag size={24} color={Colors.secondary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.po, { color: colors.text }]}>{item.po}</Text>
              <Text style={[styles.supplier, { color: colors.textSecondary }]}>{item.supplier}</Text>
              <Text style={[styles.date, { color: colors.textMuted }]}>{item.date} · {item.items} items</Text>
            </View>
            <View style={{ alignItems: 'flex-end', gap: 4 }}>
              <Text style={[styles.total, { color: Colors.primary }]}>ETB {item.total.toLocaleString()}</Text>
              <Badge label={item.status.charAt(0).toUpperCase() + item.status.slice(1)} variant={statusVariant[item.status]} />
            </View>
          </TouchableOpacity>
        )}
      />

      {/* Detail Modal */}
      <Modal visible={showDetail} animationType="slide" presentationStyle="pageSheet">
        {selected && (
          <View style={[styles.modal, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>{selected.po}</Text>
              <TouchableOpacity onPress={() => setShowDetail(false)}><X size={24} color={colors.text} /></TouchableOpacity>
            </View>
            <ScrollView style={{ padding: Spacing.md }}>
              <Card>
                {[['Supplier', selected.supplier], ['Date', selected.date], ['Items', String(selected.items)], ['Total', `ETB ${selected.total.toLocaleString()}`], ['Status', selected.status]].map(([label, value], i) => (
                  <View key={i} style={[styles.detailRow, { borderBottomColor: colors.divider, borderBottomWidth: i < 4 ? 1 : 0 }]}>
                    <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>{label}</Text>
                    <Text style={[styles.detailValue, { color: colors.text }]}>{value}</Text>
                  </View>
                ))}
              </Card>
              {selected.status === 'pending' && (
                <Button title="Receive Stock" onPress={() => { Alert.alert('Success', 'Stock received'); setShowDetail(false); }} style={{ marginTop: Spacing.md }} variant="success" />
              )}
              <Button title="Record Payment" onPress={() => Alert.alert('Payment', 'Payment recorded')} style={{ marginTop: Spacing.sm }} variant="outline" />
            </ScrollView>
          </View>
        )}
      </Modal>

      {/* Add Form Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t('addPurchase')}</Text>
            <TouchableOpacity onPress={() => setShowForm(false)}><X size={24} color={colors.text} /></TouchableOpacity>
          </View>
          <ScrollView style={{ padding: Spacing.md }} keyboardShouldPersistTaps="handled">
            <Input label="Supplier" value={form.supplier} onChangeText={(v) => setForm((p) => ({ ...p, supplier: v }))} placeholder="Supplier name" />
            <Input label="Number of Items" value={form.items} onChangeText={(v) => setForm((p) => ({ ...p, items: v }))} keyboardType="numeric" placeholder="0" />
            <Input label="Total Amount (ETB)" value={form.total} onChangeText={(v) => setForm((p) => ({ ...p, total: v }))} keyboardType="numeric" placeholder="0.00" />
            <Input label="Note" value={form.note} onChangeText={(v) => setForm((p) => ({ ...p, note: v }))} placeholder="Optional note" />
            <Button title={t('save')} onPress={handleSave} style={{ marginBottom: Spacing.xxl }} />
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  addBtn: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  list: { padding: Spacing.sm, gap: Spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', padding: Spacing.sm, borderRadius: Radius.md, borderWidth: 1, gap: Spacing.sm },
  icon: { width: 52, height: 52, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  po: { fontSize: FontSize.md, fontWeight: '700' },
  supplier: { fontSize: FontSize.sm, marginTop: 2 },
  date: { fontSize: FontSize.xs, marginTop: 2 },
  total: { fontSize: FontSize.sm, fontWeight: '700' },
  modal: { flex: 1 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: Spacing.sm },
  detailLabel: { fontSize: FontSize.sm },
  detailValue: { fontSize: FontSize.sm, fontWeight: '600' },
});
