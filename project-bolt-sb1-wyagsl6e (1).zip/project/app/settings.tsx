import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Moon, Sun, Globe, DollarSign, Receipt, Percent, ChevronRight } from 'lucide-react-native';
import { Card } from '@/components/ui/Card';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

export default function SettingsScreen() {
  const { colors, isDark, t, theme, language } = useTheme();
  const { setTheme, setLanguage } = useAppStore();

  const toggleTheme = () => setTheme(isDark ? 'light' : 'dark');
  const toggleLanguage = () => setLanguage(language === 'en' ? 'am' : 'en');

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader title={t('settings')} showBack />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.body}>

          {/* Appearance */}
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>APPEARANCE</Text>
          <Card>
            <View style={styles.settingRow}>
              <View style={[styles.settingIcon, { backgroundColor: isDark ? '#FEF3C7' : '#F1F5F9' }]}>
                {isDark ? <Moon size={18} color={Colors.warning} /> : <Sun size={18} color='#64748B' />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.settingLabel, { color: colors.text }]}>
                  {isDark ? t('darkMode') : t('lightMode')}
                </Text>
                <Text style={[styles.settingDesc, { color: colors.textMuted }]}>
                  {isDark ? 'Switch to light mode' : 'Switch to dark mode'}
                </Text>
              </View>
              <Switch
                value={isDark}
                onValueChange={toggleTheme}
                trackColor={{ false: colors.border, true: Colors.primary }}
                thumbColor="#fff"
              />
            </View>
          </Card>

          {/* Language */}
          <Text style={[styles.sectionTitle, { color: colors.textSecondary, marginTop: Spacing.lg }]}>LANGUAGE</Text>
          <Card>
            <TouchableOpacity style={styles.settingRow} onPress={toggleLanguage}>
              <View style={[styles.settingIcon, { backgroundColor: '#DBEAFE' }]}>
                <Globe size={18} color={Colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.settingLabel, { color: colors.text }]}>{t('language')}</Text>
                <Text style={[styles.settingDesc, { color: colors.textMuted }]}>
                  {language === 'en' ? 'English' : 'Amharic (አማርኛ)'}
                </Text>
              </View>
              <View style={styles.langRow}>
                <TouchableOpacity
                  style={[styles.langChip, { backgroundColor: language === 'en' ? Colors.primary : colors.surfaceSecondary }]}
                  onPress={() => setLanguage('en')}
                >
                  <Text style={[styles.langText, { color: language === 'en' ? '#fff' : colors.textSecondary }]}>EN</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.langChip, { backgroundColor: language === 'am' ? Colors.primary : colors.surfaceSecondary }]}
                  onPress={() => setLanguage('am')}
                >
                  <Text style={[styles.langText, { color: language === 'am' ? '#fff' : colors.textSecondary }]}>AM</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </Card>

          {/* Business */}
          <Text style={[styles.sectionTitle, { color: colors.textSecondary, marginTop: Spacing.lg }]}>BUSINESS</Text>
          <Card>
            {[
              { icon: DollarSign, label: t('currency'), desc: 'Ethiopian Birr (ETB)', color: '#D1FAE5', iconColor: Colors.success },
              { icon: Percent, label: t('taxSettings'), desc: 'VAT 15%', color: '#EDE9FE', iconColor: Colors.secondary },
              { icon: Receipt, label: t('receiptSettings'), desc: 'A4, Logo enabled', color: '#FEE2E2', iconColor: Colors.danger },
            ].map((item, i) => (
              <TouchableOpacity
                key={item.label}
                style={[styles.settingRow, i < 2 && { borderBottomWidth: 1, borderBottomColor: colors.divider }]}
                onPress={() => Alert.alert(item.label, 'Setting coming soon')}
              >
                <View style={[styles.settingIcon, { backgroundColor: item.color }]}>
                  <item.icon size={18} color={item.iconColor} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.settingLabel, { color: colors.text }]}>{item.label}</Text>
                  <Text style={[styles.settingDesc, { color: colors.textMuted }]}>{item.desc}</Text>
                </View>
                <ChevronRight size={16} color={colors.textMuted} />
              </TouchableOpacity>
            ))}
          </Card>

          {/* App Info */}
          <Text style={[styles.sectionTitle, { color: colors.textSecondary, marginTop: Spacing.lg }]}>ABOUT</Text>
          <Card>
            {[['App Version', '1.0.0'], ['Build', '2025.06'], ['Platform', 'Android / iOS']].map(([label, value]) => (
              <View key={label} style={[styles.infoRow, { borderBottomColor: colors.divider }]}>
                <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>{label}</Text>
                <Text style={[styles.infoValue, { color: colors.text }]}>{value}</Text>
              </View>
            ))}
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  body: { padding: Spacing.md, paddingBottom: Spacing.xxl },
  sectionTitle: { fontSize: FontSize.xs, fontWeight: '700', letterSpacing: 0.5, marginBottom: Spacing.sm },
  settingRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, gap: Spacing.sm },
  settingIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  settingLabel: { fontSize: FontSize.md, fontWeight: '500' },
  settingDesc: { fontSize: FontSize.xs, marginTop: 2 },
  langRow: { flexDirection: 'row', gap: 4 },
  langChip: { borderRadius: Radius.sm, paddingHorizontal: 10, paddingVertical: 5 },
  langText: { fontSize: FontSize.xs, fontWeight: '700' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: Spacing.sm, borderBottomWidth: 1 },
  infoLabel: { fontSize: FontSize.sm },
  infoValue: { fontSize: FontSize.sm, fontWeight: '600' },
});
