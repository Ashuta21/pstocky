import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Store, CheckCircle } from 'lucide-react-native';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const DEMO_STORES = [
  { id: 1, name: 'Main Branch - Bole', plan: 'Pro', status: 'active', location: 'Addis Ababa, Bole' },
  { id: 2, name: 'Branch 2 - Piassa', plan: 'Starter', status: 'active', location: 'Addis Ababa, Piassa' },
  { id: 3, name: 'Branch 3 - Merkato', plan: 'Pro', status: 'inactive', location: 'Addis Ababa, Merkato' },
];

export default function StoresScreen() {
  const { colors, t } = useTheme();
  const { currentStore, setCurrentStore } = useAppStore();
  const [stores] = useState(DEMO_STORES);
  const activeStore = currentStore ?? stores[0];

  const handleSwitch = (store: typeof DEMO_STORES[0]) => {
    Alert.alert(
      t('switchStore'),
      `Switch to ${store.name}?`,
      [
        { text: t('cancel'), style: 'cancel' },
        { text: t('confirm'), onPress: () => setCurrentStore(store) },
      ]
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader title={t('stores')} showBack />
      <FlatList
        data={stores}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <Text style={[styles.header, { color: colors.textSecondary }]}>{t('currentStore').toUpperCase()}</Text>
        }
        renderItem={({ item }) => {
          const isActive = activeStore?.id === item.id;
          return (
            <TouchableOpacity
              style={[
                styles.storeCard,
                {
                  backgroundColor: colors.card,
                  borderColor: isActive ? Colors.primary : colors.border,
                  borderWidth: isActive ? 2 : 1,
                },
              ]}
              onPress={() => handleSwitch(item)}
            >
              <View style={[styles.storeIcon, { backgroundColor: isActive ? Colors.primary + '18' : colors.surfaceSecondary }]}>
                <Store size={28} color={isActive ? Colors.primary : colors.textSecondary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.storeName, { color: colors.text }]}>{item.name}</Text>
                <Text style={[styles.storeLocation, { color: colors.textSecondary }]}>{item.location}</Text>
                <View style={styles.storeFooter}>
                  <Badge label={item.plan} variant={item.plan === 'Pro' ? 'secondary' : 'neutral'} />
                  <Badge label={item.status} variant={item.status === 'active' ? 'success' : 'neutral'} />
                </View>
              </View>
              {isActive && <CheckCircle size={24} color={Colors.primary} />}
            </TouchableOpacity>
          );
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { padding: Spacing.md, gap: Spacing.sm },
  header: { fontSize: FontSize.xs, fontWeight: '700', letterSpacing: 0.5, marginBottom: Spacing.sm },
  storeCard: { flexDirection: 'row', alignItems: 'center', padding: Spacing.md, borderRadius: Radius.lg, gap: Spacing.md },
  storeIcon: { width: 56, height: 56, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  storeName: { fontSize: FontSize.md, fontWeight: '700', marginBottom: 4 },
  storeLocation: { fontSize: FontSize.sm, marginBottom: 8 },
  storeFooter: { flexDirection: 'row', gap: 8 },
});
