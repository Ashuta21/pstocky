import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Bell, AlertTriangle, ShoppingCart, CreditCard, DollarSign, CheckCheck } from 'lucide-react-native';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { Button } from '@/components/ui/Button';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const DEMO_NOTIFS = [
  { id: 1, type: 'low_stock', title: 'Low Stock Alert', body: 'iPhone 15 Pro has only 2 units remaining', time: '2m ago', read: false },
  { id: 2, type: 'order', title: 'New Order Received', body: 'Order #148 from Abebe Girma - ETB 3,000', time: '15m ago', read: false },
  { id: 3, type: 'payment', title: 'Payment Received', body: 'ETB 2,500 from Mekdes Alemu', time: '1h ago', read: true },
  { id: 4, type: 'subscription', title: 'Subscription Expiry', body: 'Your Pro plan expires in 7 days', time: '3h ago', read: true },
  { id: 5, type: 'low_stock', title: 'Low Stock Alert', body: 'Adidas Ultraboost is out of stock', time: '5h ago', read: true },
  { id: 6, type: 'payment', title: 'Payment Received', body: 'ETB 5,000 from Yonas Tadesse', time: '1d ago', read: true },
];

const typeConfig: Record<string, { icon: any; color: string; bg: string }> = {
  low_stock: { icon: AlertTriangle, color: Colors.warning, bg: '#FEF3C7' },
  order: { icon: ShoppingCart, color: Colors.primary, bg: '#DBEAFE' },
  payment: { icon: DollarSign, color: Colors.success, bg: '#D1FAE5' },
  subscription: { icon: CreditCard, color: Colors.secondary, bg: '#EDE9FE' },
};

export default function NotificationsScreen() {
  const { colors, t } = useTheme();
  const [notifs, setNotifs] = useState(DEMO_NOTIFS);

  const markAllRead = () => setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
  const unreadCount = notifs.filter((n) => !n.read).length;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader
        title={t('notifications') + (unreadCount > 0 ? ` (${unreadCount})` : '')}
        showBack
        right={
          unreadCount > 0 ? (
            <TouchableOpacity onPress={markAllRead}>
              <CheckCheck size={20} color={Colors.primary} />
            </TouchableOpacity>
          ) : undefined
        }
      />

      <FlatList
        data={notifs}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => {
          const cfg = typeConfig[item.type];
          return (
            <TouchableOpacity
              style={[
                styles.notifRow,
                {
                  backgroundColor: item.read ? colors.card : colors.card,
                  borderColor: item.read ? colors.border : Colors.primary + '30',
                  borderLeftWidth: item.read ? 1 : 3,
                  borderLeftColor: item.read ? colors.border : Colors.primary,
                },
              ]}
              onPress={() => setNotifs((prev) => prev.map((n) => n.id === item.id ? { ...n, read: true } : n))}
            >
              <View style={[styles.notifIcon, { backgroundColor: cfg.bg }]}>
                <cfg.icon size={20} color={cfg.color} />
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.notifTop}>
                  <Text style={[styles.notifTitle, { color: colors.text }]}>{item.title}</Text>
                  {!item.read && <View style={styles.unreadDot} />}
                </View>
                <Text style={[styles.notifBody, { color: colors.textSecondary }]}>{item.body}</Text>
                <Text style={[styles.notifTime, { color: colors.textMuted }]}>{item.time}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Bell size={48} color={colors.textMuted} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>No notifications</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { padding: Spacing.sm, gap: Spacing.sm },
  notifRow: { flexDirection: 'row', alignItems: 'flex-start', padding: Spacing.md, borderRadius: Radius.md, borderWidth: 1, gap: Spacing.sm, borderRightWidth: 1, borderTopWidth: 1, borderBottomWidth: 1 },
  notifIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  notifTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  notifTitle: { fontSize: FontSize.sm, fontWeight: '700', flex: 1 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.primary },
  notifBody: { fontSize: FontSize.sm, lineHeight: 20, marginBottom: 4 },
  notifTime: { fontSize: FontSize.xs },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 100, gap: 12 },
  emptyText: { fontSize: FontSize.md },
});
