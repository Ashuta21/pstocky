import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { View } from 'react-native';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { SecureStorage, Preferences } from '@/services/storage';
import { TokenManager } from '@/services/api';

function RootLayoutInner() {
  const { isDark } = useTheme();
  const [ready, setReady] = useState(false);
  const { setToken, setTheme, setLanguage } = useAppStore();

  useEffect(() => {
    async function bootstrap() {
      try {
        // Restore JWT from secure storage
        const token = await SecureStorage.getToken();
        if (token) {
          TokenManager.setToken(token);
          setToken(token);
        }

        const refreshToken = await SecureStorage.getRefreshToken();
        if (refreshToken) {
          TokenManager.setRefreshToken(refreshToken);
        }

        // Restore user preferences
        const prefs = await Preferences.load();
        if (prefs.theme) setTheme(prefs.theme);
        if (prefs.language) setLanguage(prefs.language);
      } catch {
        // If bootstrap fails, continue with defaults
      } finally {
        setReady(true);
      }
    }

    bootstrap();
  }, []);

  if (!ready) return <View style={{ flex: 1 }} />;

  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="splash" />
        <Stack.Screen name="index" />
        <Stack.Screen name="login" />
        <Stack.Screen name="forgot-password" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="suppliers" />
        <Stack.Screen name="purchases" />
        <Stack.Screen name="reports-full" />
        <Stack.Screen name="notifications" />
        <Stack.Screen name="profile" />
        <Stack.Screen name="settings" />
        <Stack.Screen name="stores" />
        <Stack.Screen name="subscription" />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style={isDark ? 'light' : 'dark'} />
    </>
  );
}

export default function RootLayout() {
  useFrameworkReady();
  return <RootLayoutInner />;
}
