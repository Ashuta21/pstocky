import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Plus, Truck, Phone, Mail, MapPin, X, ChevronRight, Edit2, Trash2 } from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const DEMO_SUPPLIERS = [
  { id: 1, name: 'Ethio Electronics PLC', phone: '+251911001122', email: 'info@ethioelec.com', address: 'Addis Ababa', balance: 15000, totalPurchases: 250000 },
  { id: 2, name: 'Fasika Trading', phone: '+251922002233', email: 'fasika@trade.com', address: 'Addis Ababa', balance: 0, totalPurchases: 88000 },
  { id: 3, name: 'Abay Imports', phone: '+251933003344', email: 'abay@imports.et', address: 'Dire Dawa', balance: 5000, totalPurchases: 120000 },
];

export default function SuppliersScreen() {
  const { colors, t } = useTheme();
  const [search, setSearch] = useState('');
  const [suppliers, setSuppliers] = useState(DEMO_SUPPLIERS);
  const [selected, setSelected] = useState<typeof DEMO_SUPPLIERS[0] | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', address: '' });

  const filtered = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.phone.includes(search)
  );

  const handleSave = () => {
    if (!form.name.trim()) { Alert.alert('Error', 'Name is required'); return; }
    if (editing && selected) {
      setSuppliers((prev) => prev.map((s) => s.id === selected.id ? { ...s, ...form } : s));
    } else {
      setSuppliers((prev) => [{ id: prev.length + 1, ...form, balance: 0, totalPurchases: 0 }, ...prev]);
    }
    setShowForm(false);
    setForm({ name: '', phone: '', email: '', address: '' });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader
        title={t('suppliers')}
        showBack
        right={
          <TouchableOpacity
            onPress={() => { setEditing(false); setForm({ name: '', phone: '', email: '', address: '' }); setShowForm(true); }}
            style={[styles.addBtn, { backgroundColor: Colors.primary }]}
          >
            <Plus size={18} color="#fff" />
          </TouchableOpacity>
        }
      />

      <View style={[styles.searchRow, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View style={[styles.searchInput, { backgroundColor: colors.input, borderColor: colors.border }]}>
          <Search size={16} color={colors.textMuted} />
          <TextInput style={[styles.searchText, { color: colors.text }]} placeholder="Search..." placeholderTextColor={colors.textMuted} value={search} onChangeText={setSearch} />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.row, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => { setSelected(item); setShowDetail(true); }}
          >
            <View style={[styles.icon, { backgroundColor: Colors.warning + '22' }]}>
              <Truck size={24} color={Colors.warning} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.name, { color: colors.text }]}>{item.name}</Text>
              <Text style={[styles.sub, { color: colors.textSecondary }]}>{item.phone}</Text>
              <Text style={[styles.sub2, { color: colors.textMuted }]}>Total: ETB {item.totalPurchases.toLocaleString()}</Text>
            </View>
            {item.balance > 0 && (
              <Text style={[styles.balance, { color: Colors.danger }]}>ETB {item.balance.toLocaleString()}</Text>
            )}
            <ChevronRight size={16} color={colors.textMuted} />
          </TouchableOpacity>
        )}
        ListEmptyComponent={<View style={styles.empty}><Truck size={48} color={colors.textMuted} /><Text style={{ color: colors.textSecondary, marginTop: 12 }}>{t('noData')}</Text></View>}
      />

      {/* Detail Modal */}
      <Modal visible={showDetail} animationType="slide" presentationStyle="pageSheet">
        {selected && (
          <View style={[styles.modal, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>{t('supplier')}</Text>
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <TouchableOpacity onPress={() => { setForm({ name: selected.name, phone: selected.phone, email: selected.email, address: selected.address }); setEditing(true); setShowDetail(false); setShowForm(true); }}>
                  <Edit2 size={20} color={Colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setShowDetail(false)}>
                  <X size={24} color={colors.text} />
                </TouchableOpacity>
              </View>
            </View>
            <ScrollView style={{ padding: Spacing.md }}>
              <Card>
                {[[<Truck size={14} color={colors.textMuted} />, selected.name], [<Phone size={14} color={colors.textMuted} />, selected.phone], [<Mail size={14} color={colors.textMuted} />, selected.email], [<MapPin size={14} color={colors.textMuted} />, selected.address]].map(([icon, val], i) => (
                  <View key={i} style={[styles.infoRow, { borderBottomColor: colors.divider, borderBottomWidth: i < 3 ? 1 : 0 }]}>
                    {icon}<Text style={[styles.infoText, { color: colors.text }]}>{val}</Text>
                  </View>
                ))}
              </Card>
              <View style={[styles.statsRow]}>
                <Card style={styles.statMini}><Text style={[styles.statVal, { color: Colors.primary }]}>ETB {selected.totalPurchases.toLocaleString()}</Text><Text style={[styles.statLabel, { color: colors.textSecondary }]}>Total Purchased</Text></Card>
                <Card style={styles.statMini}><Text style={[styles.statVal, { color: Colors.danger }]}>ETB {selected.balance.toLocaleString()}</Text><Text style={[styles.statLabel, { color: colors.textSecondary }]}>Balance Due</Text></Card>
              </View>
            </ScrollView>
          </View>
        )}
      </Modal>

      {/* Form Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{editing ? t('editSupplier') : t('addSupplier')}</Text>
            <TouchableOpacity onPress={() => setShowForm(false)}><X size={24} color={colors.text} /></TouchableOpacity>
          </View>
          <ScrollView style={{ padding: Spacing.md }} keyboardShouldPersistTaps="handled">
            <Input label={t('name')} value={form.name} onChangeText={(v) => setForm((p) => ({ ...p, name: v }))} placeholder="Supplier name" />
            <Input label={t('phone')} value={form.phone} onChangeText={(v) => setForm((p) => ({ ...p, phone: v }))} keyboardType="phone-pad" placeholder="+251..." />
            <Input label={t('email')} value={form.email} onChangeText={(v) => setForm((p) => ({ ...p, email: v }))} autoCapitalize="none" placeholder="email@supplier.com" />
            <Input label={t('address')} value={form.address} onChangeText={(v) => setForm((p) => ({ ...p, address: v }))} placeholder="City" />
            <Button title={t('save')} onPress={handleSave} style={{ marginBottom: Spacing.xxl }} />
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  addBtn: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  searchRow: { padding: Spacing.sm, borderBottomWidth: 1 },
  searchInput: { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, paddingHorizontal: Spacing.sm, height: 40, borderWidth: 1, gap: 8 },
  searchText: { flex: 1, fontSize: FontSize.sm },
  list: { padding: Spacing.sm, gap: Spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', padding: Spacing.sm, borderRadius: Radius.md, borderWidth: 1, gap: Spacing.sm },
  icon: { width: 52, height: 52, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: FontSize.md, fontWeight: '600' },
  sub: { fontSize: FontSize.sm, marginTop: 2 },
  sub2: { fontSize: FontSize.xs, marginTop: 2 },
  balance: { fontSize: FontSize.sm, fontWeight: '700', marginRight: 4 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80 },
  modal: { flex: 1 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  infoRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, gap: 8 },
  infoText: { fontSize: FontSize.sm, flex: 1 },
  statsRow: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.md },
  statMini: { flex: 1, alignItems: 'center' },
  statVal: { fontSize: FontSize.lg, fontWeight: '700' },
  statLabel: { fontSize: FontSize.xs, marginTop: 4 },
});
