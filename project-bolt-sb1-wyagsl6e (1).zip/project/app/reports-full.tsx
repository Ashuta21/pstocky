import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BarChart2, TrendingUp, Package, Users, Truck, FileText, Download } from 'lucide-react-native';
import { Card } from '@/components/ui/Card';
import { SimpleBarChart } from '@/components/ui/SimpleBarChart';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { Button } from '@/components/ui/Button';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const REPORT_TYPES = [
  { label: 'Daily Sales', icon: BarChart2, color: Colors.primary },
  { label: 'Monthly Sales', icon: TrendingUp, color: Colors.secondary },
  { label: 'Profit & Loss', icon: FileText, color: Colors.success },
  { label: 'Inventory', icon: Package, color: Colors.warning },
  { label: 'Customer', icon: Users, color: '#EC4899' },
  { label: 'Supplier', icon: Truck, color: '#06B6D4' },
];

const DAILY_DATA = [
  { label: 'Mon', value: 8200 },
  { label: 'Tue', value: 12400 },
  { label: 'Wed', value: 9800 },
  { label: 'Thu', value: 15200 },
  { label: 'Fri', value: 11000 },
  { label: 'Sat', value: 18500 },
  { label: 'Sun', value: 6300 },
];

const MONTHLY_DATA = [
  { label: 'Jan', value: 220000 },
  { label: 'Feb', value: 190000 },
  { label: 'Mar', value: 280000 },
  { label: 'Apr', value: 310000 },
  { label: 'May', value: 260000 },
  { label: 'Jun', value: 290000 },
];

const PL_ROWS = [
  ['Total Revenue', 'ETB 284,300', Colors.success],
  ['Cost of Goods', 'ETB 182,000', Colors.danger],
  ['Gross Profit', 'ETB 102,300', Colors.primary],
  ['Operating Expenses', 'ETB 34,000', Colors.danger],
  ['Net Profit', 'ETB 68,300', Colors.success],
];

export default function ReportsScreen() {
  const { colors, t } = useTheme();
  const [active, setActive] = useState('Daily Sales');

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader title={t('reportsTitle')} showBack />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Report Type Picker */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.typePicker}>
          {REPORT_TYPES.map((rt) => (
            <TouchableOpacity
              key={rt.label}
              style={[
                styles.typeChip,
                {
                  backgroundColor: active === rt.label ? rt.color : colors.surfaceSecondary,
                  borderColor: active === rt.label ? rt.color : colors.border,
                },
              ]}
              onPress={() => setActive(rt.label)}
            >
              <rt.icon size={14} color={active === rt.label ? '#fff' : colors.textSecondary} />
              <Text style={[styles.typeLabel, { color: active === rt.label ? '#fff' : colors.textSecondary }]}>
                {rt.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.body}>
          {active === 'Daily Sales' && (
            <Card>
              <SimpleBarChart data={DAILY_DATA} color={Colors.primary} title="Daily Sales (This Week)" height={200} />
              <View style={[styles.divider, { backgroundColor: colors.divider }]} />
              {[['Total Sales', 'ETB 81,400'], ['Transactions', '147'], ['Avg. Sale', 'ETB 554']].map(([label, value]) => (
                <View key={label} style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text>
                </View>
              ))}
            </Card>
          )}

          {active === 'Monthly Sales' && (
            <Card>
              <SimpleBarChart data={MONTHLY_DATA} color={Colors.secondary} title="Monthly Sales (2025)" height={200} />
              <View style={[styles.divider, { backgroundColor: colors.divider }]} />
              {[['Total (YTD)', 'ETB 1,550,000'], ['Best Month', 'April - ETB 310,000'], ['Growth', '+12.4%']].map(([label, value]) => (
                <View key={label} style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text>
                </View>
              ))}
            </Card>
          )}

          {active === 'Profit & Loss' && (
            <Card>
              <Text style={[styles.plTitle, { color: colors.text }]}>Profit & Loss Statement</Text>
              <Text style={[styles.plPeriod, { color: colors.textMuted }]}>June 2025</Text>
              {PL_ROWS.map(([label, value, color]) => (
                <View key={label as string} style={[styles.summaryRow, { marginTop: Spacing.sm }]}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: color as string, fontWeight: '700' }]}>{value}</Text>
                </View>
              ))}
            </Card>
          )}

          {active === 'Inventory' && (
            <Card>
              {[['Total Products', '892'], ['Total Stock Value', 'ETB 1,240,000'], ['Low Stock Items', '8'], ['Out of Stock', '3'], ['Categories', '12']].map(([label, value]) => (
                <View key={label} style={[styles.summaryRow, { marginBottom: Spacing.sm }]}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text>
                </View>
              ))}
            </Card>
          )}

          {active === 'Customer' && (
            <Card>
              {[['Total Customers', '234'], ['Active (30d)', '89'], ['New (This Month)', '12'], ['Total Receivables', 'ETB 42,500'], ['Avg. Purchase', 'ETB 1,200']].map(([label, value]) => (
                <View key={label} style={[styles.summaryRow, { marginBottom: Spacing.sm }]}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text>
                </View>
              ))}
            </Card>
          )}

          {active === 'Supplier' && (
            <Card>
              {[['Total Suppliers', '18'], ['Total Payables', 'ETB 20,000'], ['Purchases (Month)', 'ETB 152,000'], ['Purchase Orders', '12'], ['Pending Delivery', '2']].map(([label, value]) => (
                <View key={label} style={[styles.summaryRow, { marginBottom: Spacing.sm }]}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text>
                </View>
              ))}
            </Card>
          )}

          {/* Export Buttons */}
          <View style={styles.exportRow}>
            <Button
              title={t('exportPDF')}
              onPress={() => Alert.alert('Export', 'PDF exported')}
              variant="outline"
              size="sm"
              icon={<Download size={14} color={Colors.primary} />}
              style={{ flex: 1 }}
            />
            <Button
              title={t('exportExcel')}
              onPress={() => Alert.alert('Export', 'Excel exported')}
              variant="success"
              size="sm"
              icon={<Download size={14} color="#fff" />}
              style={{ flex: 1 }}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  typePicker: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm },
  typeChip: { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.full, paddingHorizontal: Spacing.md, paddingVertical: 8, marginRight: Spacing.sm, borderWidth: 1.5, gap: 6 },
  typeLabel: { fontSize: FontSize.sm, fontWeight: '500' },
  body: { padding: Spacing.md, gap: Spacing.md },
  divider: { height: 1, marginVertical: Spacing.md },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryLabel: { fontSize: FontSize.sm },
  summaryValue: { fontSize: FontSize.sm, fontWeight: '600' },
  plTitle: { fontSize: FontSize.lg, fontWeight: '700', marginBottom: 4 },
  plPeriod: { fontSize: FontSize.sm, marginBottom: Spacing.sm },
  exportRow: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.sm, marginBottom: Spacing.xl },
});
