import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  TrendingUp,
  ShoppingCart,
  Package,
  Users,
  AlertTriangle,
  DollarSign,
  Plus,
  UserPlus,
  BarChart2,
  ShoppingBag,
  Bell,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { Card } from '@/components/ui/Card';
import { StatCard } from '@/components/ui/StatCard';
import { SimpleBarChart } from '@/components/ui/SimpleBarChart';
import { Badge } from '@/components/ui/Badge';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { Colors, FontSize, Spacing, Radius } from '@/constants/theme';
import { getDashboard } from '@/services/api';

const { width: SCREEN_W } = Dimensions.get('window');

const DEMO_STATS = {
  todaySales: 'ETB 12,450',
  monthlyRevenue: 'ETB 284,300',
  totalOrders: '147',
  lowStock: '8',
  activeCustomers: '234',
  totalProducts: '892',
};

const DEMO_SALES = [
  { label: 'Mon', value: 8200 },
  { label: 'Tue', value: 12400 },
  { label: 'Wed', value: 9800 },
  { label: 'Thu', value: 15200 },
  { label: 'Fri', value: 11000 },
  { label: 'Sat', value: 18500 },
  { label: 'Sun', value: 6300 },
];

const DEMO_TOP_PRODUCTS = [
  { name: 'Samsung TV 55"', sold: 42, revenue: 'ETB 126,000' },
  { name: 'iPhone 15 Pro', sold: 31, revenue: 'ETB 186,000' },
  { name: 'Sony Headphones', sold: 28, revenue: 'ETB 42,000' },
  { name: 'Nike Air Max', sold: 55, revenue: 'ETB 82,500' },
];

export default function DashboardScreen() {
  const { colors, isDark, t, Colors: C } = useTheme();
  const { user, currentStore } = useAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState(DEMO_STATS);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1200);
  }, []);

  const quickActions = [
    { label: t('newSale'), icon: <ShoppingCart size={20} color="#fff" />, color: Colors.primary, route: '/(tabs)/pos' },
    { label: t('addProduct'), icon: <Plus size={20} color="#fff" />, color: Colors.secondary, route: '/(tabs)/inventory' },
    { label: t('addCustomer'), icon: <UserPlus size={20} color="#fff" />, color: Colors.success, route: '/(tabs)/customers' },
    { label: t('purchaseStock'), icon: <ShoppingBag size={20} color="#fff" />, color: Colors.warning, route: '/(tabs)/purchases' },
    { label: t('reports'), icon: <BarChart2 size={20} color="#fff" />, color: '#EC4899', route: '/(tabs)/reports' },
  ];

  const statCards = [
    { title: t('todaySales'), value: stats.todaySales, icon: <DollarSign size={18} color="#fff" />, gradient: [Colors.primary, '#2563EB'] as [string, string], trend: 12 },
    { title: t('monthlyRevenue'), value: stats.monthlyRevenue, icon: <TrendingUp size={18} color="#fff" />, gradient: [Colors.secondary, '#7C3AED'] as [string, string], trend: 8 },
    { title: t('totalOrders'), value: stats.totalOrders, icon: <ShoppingCart size={18} color="#fff" />, gradient: [Colors.success, '#059669'] as [string, string], trend: 5 },
    { title: t('lowStock'), value: stats.lowStock, icon: <AlertTriangle size={18} color="#fff" />, gradient: [Colors.warning, '#D97706'] as [string, string] },
    { title: t('activeCustomers'), value: stats.activeCustomers, icon: <Users size={18} color="#fff" />, gradient: ['#EC4899', '#DB2777'] as [string, string], trend: 3 },
    { title: t('totalProducts'), value: stats.totalProducts, icon: <Package size={18} color="#fff" />, gradient: ['#06B6D4', '#0284C7'] as [string, string] },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
        }
      >
        {/* Header */}
        <LinearGradient colors={['#0F172A', '#1E3A5F']} style={styles.header}>
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.greeting}>Good morning,</Text>
              <Text style={styles.userName}>{user?.name ?? 'Demo User'}</Text>
              {currentStore && (
                <Text style={styles.storeName}>{currentStore.name}</Text>
              )}
            </View>
            <TouchableOpacity
              style={styles.notifBtn}
              onPress={() => router.push('/notifications')}
            >
              <Bell size={22} color="#fff" />
              <View style={styles.notifDot} />
            </TouchableOpacity>
          </View>
        </LinearGradient>

        <View style={styles.body}>
          {/* Stat Cards */}
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Overview</Text>
          <View style={styles.statsGrid}>
            {statCards.map((card, i) => (
              <View key={i} style={styles.statItem}>
                <StatCard {...card} />
              </View>
            ))}
          </View>

          {/* Quick Actions */}
          <Text style={[styles.sectionTitle, { color: colors.text }]}>{t('quickActions')}</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.actionsScroll}>
            {quickActions.map((action, i) => (
              <TouchableOpacity
                key={i}
                style={styles.actionItem}
                onPress={() => router.push(action.route as any)}
              >
                <View style={[styles.actionIcon, { backgroundColor: action.color }]}>
                  {action.icon}
                </View>
                <Text style={[styles.actionLabel, { color: colors.text }]} numberOfLines={2}>
                  {action.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Sales Chart */}
          <Card style={styles.chartCard}>
            <SimpleBarChart
              data={DEMO_SALES}
              color={Colors.primary}
              title={t('salesOverview') + ' (Weekly)'}
              height={180}
            />
          </Card>

          {/* Top Products */}
          <Text style={[styles.sectionTitle, { color: colors.text }]}>{t('topProducts')}</Text>
          <Card>
            {DEMO_TOP_PRODUCTS.map((p, i) => (
              <View
                key={i}
                style={[
                  styles.topProductRow,
                  i < DEMO_TOP_PRODUCTS.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.divider },
                ]}
              >
                <View style={[styles.rankBadge, { backgroundColor: colors.surfaceSecondary }]}>
                  <Text style={[styles.rankText, { color: colors.textSecondary }]}>#{i + 1}</Text>
                </View>
                <View style={styles.productInfo}>
                  <Text style={[styles.productName, { color: colors.text }]}>{p.name}</Text>
                  <Text style={[styles.productSold, { color: colors.textSecondary }]}>
                    {p.sold} units sold
                  </Text>
                </View>
                <Text style={[styles.productRevenue, { color: Colors.success }]}>{p.revenue}</Text>
              </View>
            ))}
          </Card>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xl,
    paddingTop: Spacing.md,
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  greeting: { color: 'rgba(255,255,255,0.6)', fontSize: FontSize.sm },
  userName: { color: '#fff', fontSize: FontSize.xl, fontWeight: '700' },
  storeName: { color: 'rgba(255,255,255,0.5)', fontSize: FontSize.xs, marginTop: 2 },
  notifBtn: { position: 'relative', padding: 4 },
  notifDot: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.danger,
    borderWidth: 1.5,
    borderColor: '#1E3A5F',
  },
  body: { padding: Spacing.md, marginTop: -Spacing.md },
  sectionTitle: { fontSize: FontSize.lg, fontWeight: '700', marginBottom: Spacing.sm, marginTop: Spacing.md },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  statItem: { width: (SCREEN_W - Spacing.md * 2 - Spacing.sm) / 2 },
  actionsScroll: { marginBottom: Spacing.sm },
  actionItem: { alignItems: 'center', marginRight: Spacing.md, width: 72 },
  actionIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  actionLabel: { fontSize: FontSize.xs, textAlign: 'center', fontWeight: '500' },
  chartCard: { marginBottom: Spacing.md },
  topProductRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm + 4,
    gap: Spacing.sm,
  },
  rankBadge: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankText: { fontSize: FontSize.sm, fontWeight: '700' },
  productInfo: { flex: 1 },
  productName: { fontSize: FontSize.sm, fontWeight: '600' },
  productSold: { fontSize: FontSize.xs, marginTop: 2 },
  productRevenue: { fontSize: FontSize.sm, fontWeight: '700' },
});
