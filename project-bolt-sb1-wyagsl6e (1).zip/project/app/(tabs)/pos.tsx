import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
  Alert,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Search,
  Scan,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  X,
  CheckCircle,
  Printer,
} from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const { width: SW } = Dimensions.get('window');

const DEMO_PRODUCTS = [
  { id: 1, name: 'Samsung TV 55"', sku: 'SAM-TV-55', price: 3000, stock: 12, category: 'Electronics', image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: 2, name: 'iPhone 15 Pro', sku: 'APL-IP15P', price: 6000, stock: 5, category: 'Electronics', image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: 3, name: 'Nike Air Max 90', sku: 'NIK-AM90', price: 1500, stock: 30, category: 'Footwear', image: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: 4, name: 'Sony WH-1000XM5', sku: 'SNY-WH5', price: 1800, stock: 8, category: 'Electronics', image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: 5, name: 'Adidas Ultraboost', sku: 'ADI-UB22', price: 1200, stock: 20, category: 'Footwear', image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: 6, name: 'Coffee Maker Pro', sku: 'CFM-PRO', price: 800, stock: 15, category: 'Appliances', image: 'https://images.pexels.com/photos/324028/pexels-photo-324028.jpeg?auto=compress&cs=tinysrgb&w=200' },
];

const CATEGORIES = ['All', 'Electronics', 'Footwear', 'Appliances'];
const PAYMENT_METHODS = ['Cash', 'Bank Transfer', 'Telebirr', 'CBE Birr', 'Chapa', 'Credit Account'];

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  sku: string;
}

export default function POSScreen() {
  const { colors, t } = useTheme();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [cashAmount, setCashAmount] = useState('');
  const [discount, setDiscount] = useState('');

  const filtered = DEMO_PRODUCTS.filter((p) => {
    const matchCat = category === 'All' || p.category === category;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discountAmt = Number(discount) || 0;
  const tax = (subtotal - discountAmt) * 0.15;
  const total = subtotal - discountAmt + tax;
  const change = Number(cashAmount) - total;
  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);

  const addToCart = (product: typeof DEMO_PRODUCTS[0]) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) {
        return prev.map((i) => i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { id: product.id, name: product.name, price: product.price, quantity: 1, sku: product.sku }];
    });
  };

  const updateQty = (id: number, delta: number) => {
    setCart((prev) => prev
      .map((i) => i.id === id ? { ...i, quantity: i.quantity + delta } : i)
      .filter((i) => i.quantity > 0)
    );
  };

  const removeFromCart = (id: number) => setCart((prev) => prev.filter((i) => i.id !== id));

  const handleCheckout = () => {
    setShowCart(false);
    setShowCheckout(true);
  };

  const handlePayment = () => {
    if (paymentMethod === 'Cash' && Number(cashAmount) < total) {
      Alert.alert('Insufficient Amount', 'Cash amount is less than total');
      return;
    }
    setShowCheckout(false);
    setShowReceipt(true);
  };

  const handleNewSale = () => {
    setCart([]);
    setCashAmount('');
    setDiscount('');
    setShowReceipt(false);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.header, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('pointOfSale')}</Text>
        <TouchableOpacity style={styles.cartBtn} onPress={() => setShowCart(true)}>
          <ShoppingCart size={24} color={Colors.primary} />
          {cartCount > 0 && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{cartCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={[styles.searchRow, { backgroundColor: colors.surface }]}>
        <View style={[styles.searchInput, { backgroundColor: colors.input, borderColor: colors.border }]}>
          <Search size={16} color={colors.textMuted} />
          <TextInput
            style={[styles.searchText, { color: colors.text }]}
            placeholder={t('search') + ' products...'}
            placeholderTextColor={colors.textMuted}
            value={search}
            onChangeText={setSearch}
          />
        </View>
        <TouchableOpacity style={[styles.scanBtn, { backgroundColor: Colors.primary }]}>
          <Scan size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Categories */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={[styles.categoryBar, { backgroundColor: colors.surface }]}>
        {CATEGORIES.map((cat) => (
          <TouchableOpacity
            key={cat}
            style={[styles.catChip, { backgroundColor: category === cat ? Colors.primary : colors.surfaceSecondary }]}
            onPress={() => setCategory(cat)}
          >
            <Text style={[styles.catText, { color: category === cat ? '#fff' : colors.textSecondary }]}>
              {cat}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Products Grid */}
      <FlatList
        data={filtered}
        numColumns={2}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.productsGrid}
        columnWrapperStyle={styles.row}
        renderItem={({ item }) => {
          const inCart = cart.find((c) => c.id === item.id);
          return (
            <TouchableOpacity
              style={[styles.productCard, { backgroundColor: colors.card }]}
              onPress={() => addToCart(item)}
              activeOpacity={0.8}
            >
              <View style={[styles.productImgWrap, { backgroundColor: colors.surfaceSecondary }]}>
                <Text style={styles.productEmoji}>📦</Text>
              </View>
              <View style={styles.productInfo}>
                <Text style={[styles.productName, { color: colors.text }]} numberOfLines={2}>{item.name}</Text>
                <Text style={[styles.productSku, { color: colors.textMuted }]}>{item.sku}</Text>
                <View style={styles.productBottom}>
                  <Text style={[styles.productPrice, { color: Colors.primary }]}>
                    ETB {item.price.toLocaleString()}
                  </Text>
                  {inCart && (
                    <View style={styles.inCartBadge}>
                      <Text style={styles.inCartText}>{inCart.quantity}</Text>
                    </View>
                  )}
                </View>
                <Text style={[styles.stockText, { color: item.stock < 5 ? Colors.danger : colors.textMuted }]}>
                  Stock: {item.stock}
                </Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />

      {/* Cart Modal */}
      <Modal visible={showCart} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t('cart')}</Text>
            <TouchableOpacity onPress={() => setShowCart(false)}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>

          {cart.length === 0 ? (
            <View style={styles.emptyCart}>
              <ShoppingCart size={48} color={colors.textMuted} />
              <Text style={[styles.emptyCartText, { color: colors.textSecondary }]}>{t('emptyCart')}</Text>
            </View>
          ) : (
            <>
              <FlatList
                data={cart}
                keyExtractor={(item) => String(item.id)}
                style={styles.cartList}
                renderItem={({ item }) => (
                  <View style={[styles.cartItem, { borderBottomColor: colors.divider }]}>
                    <View style={styles.cartItemInfo}>
                      <Text style={[styles.cartItemName, { color: colors.text }]}>{item.name}</Text>
                      <Text style={[styles.cartItemPrice, { color: Colors.primary }]}>
                        ETB {(item.price * item.quantity).toLocaleString()}
                      </Text>
                    </View>
                    <View style={styles.cartItemActions}>
                      <TouchableOpacity onPress={() => updateQty(item.id, -1)} style={[styles.qtyBtn, { borderColor: colors.border }]}>
                        <Minus size={14} color={colors.text} />
                      </TouchableOpacity>
                      <Text style={[styles.qtyText, { color: colors.text }]}>{item.quantity}</Text>
                      <TouchableOpacity onPress={() => updateQty(item.id, 1)} style={[styles.qtyBtn, { borderColor: colors.border }]}>
                        <Plus size={14} color={colors.text} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => removeFromCart(item.id)} style={styles.removeBtn}>
                        <Trash2 size={16} color={Colors.danger} />
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              />
              <View style={[styles.cartSummary, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{t('subtotal')}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>ETB {subtotal.toLocaleString()}</Text>
                </View>
                <Button title={t('checkout')} onPress={handleCheckout} style={{ marginTop: Spacing.md }} />
              </View>
            </>
          )}
        </View>
      </Modal>

      {/* Checkout Modal */}
      <Modal visible={showCheckout} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t('checkout')}</Text>
            <TouchableOpacity onPress={() => setShowCheckout(false)}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.checkoutContent}>
            <Text style={[styles.checkoutSection, { color: colors.text }]}>{t('payment')}</Text>
            <View style={styles.paymentMethods}>
              {PAYMENT_METHODS.map((method) => (
                <TouchableOpacity
                  key={method}
                  style={[
                    styles.paymentChip,
                    {
                      backgroundColor: paymentMethod === method ? Colors.primary : colors.surfaceSecondary,
                      borderColor: paymentMethod === method ? Colors.primary : colors.border,
                    },
                  ]}
                  onPress={() => setPaymentMethod(method)}
                >
                  <Text style={[styles.paymentChipText, { color: paymentMethod === method ? '#fff' : colors.text }]}>
                    {method}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {paymentMethod === 'Cash' && (
              <View style={{ marginTop: Spacing.md }}>
                <Text style={[styles.inputLabel, { color: colors.textSecondary }]}>{t('amountPaid')}</Text>
                <TextInput
                  style={[styles.cashInput, { backgroundColor: colors.input, borderColor: colors.border, color: colors.text }]}
                  keyboardType="numeric"
                  value={cashAmount}
                  onChangeText={setCashAmount}
                  placeholder="0.00"
                  placeholderTextColor={colors.textMuted}
                />
                {Number(cashAmount) >= total && (
                  <Text style={[styles.changeText, { color: Colors.success }]}>
                    {t('change')}: ETB {change.toFixed(2)}
                  </Text>
                )}
              </View>
            )}

            <Text style={[styles.inputLabel, { color: colors.textSecondary, marginTop: Spacing.md }]}>{t('discount')} (ETB)</Text>
            <TextInput
              style={[styles.cashInput, { backgroundColor: colors.input, borderColor: colors.border, color: colors.text }]}
              keyboardType="numeric"
              value={discount}
              onChangeText={setDiscount}
              placeholder="0.00"
              placeholderTextColor={colors.textMuted}
            />

            <Card style={{ marginTop: Spacing.lg }}>
              {[
                [t('subtotal'), `ETB ${subtotal.toLocaleString()}`],
                [t('discount'), `ETB ${discountAmt.toLocaleString()}`],
                [t('tax') + ' (15%)', `ETB ${tax.toFixed(2)}`],
              ].map(([label, value]) => (
                <View key={label} style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text>
                  <Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text>
                </View>
              ))}
              <View style={[styles.totalRow, { borderTopColor: colors.divider }]}>
                <Text style={[styles.totalLabel, { color: colors.text }]}>{t('total')}</Text>
                <Text style={[styles.totalValue, { color: Colors.primary }]}>ETB {total.toFixed(2)}</Text>
              </View>
            </Card>

            <Button
              title={`Pay ETB ${total.toFixed(2)}`}
              onPress={handlePayment}
              style={{ marginTop: Spacing.lg, marginBottom: Spacing.xxl }}
            />
          </ScrollView>
        </View>
      </Modal>

      {/* Receipt Modal */}
      <Modal visible={showReceipt} animationType="fade" transparent>
        <View style={styles.receiptOverlay}>
          <View style={[styles.receiptCard, { backgroundColor: colors.surface }]}>
            <CheckCircle size={56} color={Colors.success} />
            <Text style={[styles.receiptTitle, { color: colors.text }]}>{t('paymentSuccess')}</Text>
            <Text style={[styles.receiptAmount, { color: Colors.primary }]}>ETB {total.toFixed(2)}</Text>
            <Text style={[styles.receiptMethod, { color: colors.textSecondary }]}>via {paymentMethod}</Text>
            <View style={styles.receiptActions}>
              <Button title={t('printReceipt')} onPress={() => {}} variant="outline" size="sm" icon={<Printer size={16} color={Colors.primary} />} />
              <Button title="New Sale" onPress={handleNewSale} size="sm" />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  headerTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  cartBtn: { position: 'relative', padding: 4 },
  cartBadge: { position: 'absolute', top: -4, right: -4, backgroundColor: Colors.danger, borderRadius: 10, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center' },
  cartBadgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  searchRow: { flexDirection: 'row', alignItems: 'center', padding: Spacing.sm, gap: Spacing.sm },
  searchInput: { flex: 1, flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, paddingHorizontal: Spacing.sm, height: 40, borderWidth: 1, gap: 8 },
  searchText: { flex: 1, fontSize: FontSize.sm },
  scanBtn: { width: 40, height: 40, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  categoryBar: { paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs },
  catChip: { borderRadius: Radius.full, paddingHorizontal: Spacing.md, paddingVertical: 6, marginRight: Spacing.sm },
  catText: { fontSize: FontSize.sm, fontWeight: '500' },
  productsGrid: { padding: Spacing.sm },
  row: { justifyContent: 'space-between' },
  productCard: { width: (SW - Spacing.sm * 3) / 2, borderRadius: Radius.md, marginBottom: Spacing.sm, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  productImgWrap: { height: 100, alignItems: 'center', justifyContent: 'center' },
  productEmoji: { fontSize: 40 },
  productInfo: { padding: Spacing.sm },
  productName: { fontSize: FontSize.sm, fontWeight: '600', marginBottom: 2 },
  productSku: { fontSize: FontSize.xs, marginBottom: 4 },
  productBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  productPrice: { fontSize: FontSize.sm, fontWeight: '700' },
  inCartBadge: { backgroundColor: Colors.primary, borderRadius: Radius.full, width: 20, height: 20, alignItems: 'center', justifyContent: 'center' },
  inCartText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  stockText: { fontSize: FontSize.xs, marginTop: 2 },
  modal: { flex: 1 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  emptyCart: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyCartText: { fontSize: FontSize.md },
  cartList: { flex: 1 },
  cartItem: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderBottomWidth: 1 },
  cartItemInfo: { flex: 1 },
  cartItemName: { fontSize: FontSize.sm, fontWeight: '600' },
  cartItemPrice: { fontSize: FontSize.sm, fontWeight: '700', marginTop: 2 },
  cartItemActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  qtyBtn: { width: 28, height: 28, borderRadius: 8, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  qtyText: { fontSize: FontSize.md, fontWeight: '600', width: 28, textAlign: 'center' },
  removeBtn: { padding: 4 },
  cartSummary: { padding: Spacing.md, borderTopWidth: 1 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  summaryLabel: { fontSize: FontSize.sm },
  summaryValue: { fontSize: FontSize.sm, fontWeight: '600' },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, paddingTop: Spacing.sm, marginTop: Spacing.sm },
  totalLabel: { fontSize: FontSize.lg, fontWeight: '700' },
  totalValue: { fontSize: FontSize.lg, fontWeight: '700' },
  checkoutContent: { padding: Spacing.md },
  checkoutSection: { fontSize: FontSize.lg, fontWeight: '700', marginBottom: Spacing.md },
  paymentMethods: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  paymentChip: { borderRadius: Radius.full, paddingHorizontal: Spacing.md, paddingVertical: 8, borderWidth: 1.5 },
  paymentChipText: { fontSize: FontSize.sm, fontWeight: '500' },
  inputLabel: { fontSize: FontSize.sm, fontWeight: '600', marginBottom: 6 },
  cashInput: { borderWidth: 1, borderRadius: Radius.md, paddingHorizontal: Spacing.md, height: 48, fontSize: FontSize.lg, fontWeight: '600' },
  changeText: { fontSize: FontSize.md, fontWeight: '600', marginTop: 8 },
  receiptOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  receiptCard: { width: '100%', borderRadius: Radius.xl, padding: Spacing.xl, alignItems: 'center', gap: 8 },
  receiptTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  receiptAmount: { fontSize: FontSize.xxxl, fontWeight: '800' },
  receiptMethod: { fontSize: FontSize.sm },
  receiptActions: { flexDirection: 'row', gap: Spacing.md, marginTop: Spacing.md, width: '100%' },
});
