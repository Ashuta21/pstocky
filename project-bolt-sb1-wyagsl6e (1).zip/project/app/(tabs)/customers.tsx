import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Plus, User, Phone, Mail, MapPin, X, ChevronRight, Edit2, Trash2 } from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const DEMO_CUSTOMERS = [
  { id: 1, name: 'Abebe Girma', phone: '+251911234567', email: 'abebe@email.com', address: 'Addis Ababa, Bole', balance: 5200, totalPurchases: 34500 },
  { id: 2, name: 'Tigist Bekele', phone: '+251922345678', email: 'tigist@email.com', address: 'Addis Ababa, Piassa', balance: 0, totalPurchases: 12000 },
  { id: 3, name: 'Yonas Tadesse', phone: '+251933456789', email: 'yonas@email.com', address: 'Dire Dawa', balance: -800, totalPurchases: 8900 },
  { id: 4, name: 'Mekdes Alemu', phone: '+251944567890', email: 'mekdes@email.com', address: 'Hawassa', balance: 1500, totalPurchases: 56700 },
  { id: 5, name: 'Dawit Solomon', phone: '+251955678901', email: 'dawit@email.com', address: 'Mekele', balance: 0, totalPurchases: 23400 },
];

const DEMO_TRANSACTIONS = [
  { date: '2025-06-01', type: 'Sale', amount: 3000, note: 'Invoice #102' },
  { date: '2025-05-25', type: 'Payment', amount: -2000, note: 'Cash payment' },
  { date: '2025-05-20', type: 'Sale', amount: 1500, note: 'Invoice #98' },
  { date: '2025-05-15', type: 'Payment', amount: -1000, note: 'Bank transfer' },
];

export default function CustomersScreen() {
  const { colors, t } = useTheme();
  const [search, setSearch] = useState('');
  const [customers, setCustomers] = useState(DEMO_CUSTOMERS);
  const [selected, setSelected] = useState<typeof DEMO_CUSTOMERS[0] | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', address: '' });

  const filtered = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      c.email.toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = () => {
    if (!form.name.trim()) { Alert.alert('Error', 'Name is required'); return; }
    if (editing && selected) {
      setCustomers((prev) => prev.map((c) => c.id === selected.id ? { ...c, ...form } : c));
    } else {
      setCustomers((prev) => [
        { id: prev.length + 1, ...form, balance: 0, totalPurchases: 0 },
        ...prev,
      ]);
    }
    setShowForm(false);
    setForm({ name: '', phone: '', email: '', address: '' });
  };

  const handleDelete = (id: number) => {
    Alert.alert('Delete Customer', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => setCustomers((p) => p.filter((c) => c.id !== id)) },
    ]);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={[styles.header, { backgroundColor: colors.header, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('customers')}</Text>
        <TouchableOpacity
          onPress={() => { setEditing(false); setForm({ name: '', phone: '', email: '', address: '' }); setShowForm(true); }}
          style={[styles.addBtn, { backgroundColor: Colors.primary }]}
        >
          <Plus size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={[styles.searchRow, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View style={[styles.searchInput, { backgroundColor: colors.input, borderColor: colors.border }]}>
          <Search size={16} color={colors.textMuted} />
          <TextInput
            style={[styles.searchText, { color: colors.text }]}
            placeholder="Search customers..."
            placeholderTextColor={colors.textMuted}
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.customerRow, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => { setSelected(item); setShowDetail(true); }}
          >
            <View style={[styles.avatar, { backgroundColor: Colors.primary + '22' }]}>
              <Text style={[styles.avatarText, { color: Colors.primary }]}>
                {item.name.charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={styles.customerInfo}>
              <Text style={[styles.customerName, { color: colors.text }]}>{item.name}</Text>
              <Text style={[styles.customerPhone, { color: colors.textSecondary }]}>{item.phone}</Text>
              <Text style={[styles.customerPurchases, { color: colors.textMuted }]}>
                Total: ETB {item.totalPurchases.toLocaleString()}
              </Text>
            </View>
            <View style={styles.customerRight}>
              {item.balance !== 0 && (
                <Badge
                  label={`ETB ${Math.abs(item.balance).toLocaleString()}`}
                  variant={item.balance > 0 ? 'danger' : 'success'}
                />
              )}
              <ChevronRight size={16} color={colors.textMuted} style={{ marginTop: 4 }} />
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <User size={48} color={colors.textMuted} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t('noData')}</Text>
          </View>
        }
      />

      {/* Detail Modal */}
      <Modal visible={showDetail} animationType="slide" presentationStyle="pageSheet">
        {selected && (
          <View style={[styles.modal, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>{t('customer')}</Text>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TouchableOpacity onPress={() => { setForm({ name: selected.name, phone: selected.phone, email: selected.email, address: selected.address }); setEditing(true); setShowDetail(false); setShowForm(true); }}>
                  <Edit2 size={20} color={Colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => { setShowDetail(false); handleDelete(selected.id); }}>
                  <Trash2 size={20} color={Colors.danger} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setShowDetail(false)}>
                  <X size={24} color={colors.text} />
                </TouchableOpacity>
              </View>
            </View>
            <ScrollView>
              <View style={styles.detailHero}>
                <View style={[styles.avatarLarge, { backgroundColor: Colors.primary + '22' }]}>
                  <Text style={[styles.avatarLargeText, { color: Colors.primary }]}>
                    {selected.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <Text style={[styles.detailName, { color: colors.text }]}>{selected.name}</Text>
                <Badge label={selected.balance === 0 ? 'Settled' : selected.balance > 0 ? 'Owes' : 'Credit'} variant={selected.balance === 0 ? 'success' : selected.balance > 0 ? 'danger' : 'primary'} />
              </View>

              <Card style={styles.detailCard}>
                {[
                  [<Phone size={14} color={colors.textMuted} />, selected.phone],
                  [<Mail size={14} color={colors.textMuted} />, selected.email],
                  [<MapPin size={14} color={colors.textMuted} />, selected.address],
                ].map(([icon, value], i) => (
                  <View key={i} style={[styles.infoRow, { borderBottomColor: colors.divider, borderBottomWidth: i < 2 ? 1 : 0 }]}>
                    {icon}
                    <Text style={[styles.infoText, { color: colors.text }]}>{value}</Text>
                  </View>
                ))}
              </Card>

              <View style={styles.statsRow}>
                <Card style={styles.statMini}>
                  <Text style={[styles.statMiniValue, { color: Colors.primary }]}>ETB {selected.totalPurchases.toLocaleString()}</Text>
                  <Text style={[styles.statMiniLabel, { color: colors.textSecondary }]}>Total Purchases</Text>
                </Card>
                <Card style={styles.statMini}>
                  <Text style={[styles.statMiniValue, { color: selected.balance >= 0 ? Colors.danger : Colors.success }]}>ETB {Math.abs(selected.balance).toLocaleString()}</Text>
                  <Text style={[styles.statMiniLabel, { color: colors.textSecondary }]}>Balance</Text>
                </Card>
              </View>

              <Text style={[styles.sectionTitle, { color: colors.text }]}>{t('transactions')}</Text>
              <Card style={{ margin: Spacing.md }}>
                {DEMO_TRANSACTIONS.map((tx, i) => (
                  <View key={i} style={[styles.txRow, i < DEMO_TRANSACTIONS.length - 1 && { borderBottomColor: colors.divider, borderBottomWidth: 1 }]}>
                    <View>
                      <Text style={[styles.txNote, { color: colors.text }]}>{tx.note}</Text>
                      <Text style={[styles.txDate, { color: colors.textMuted }]}>{tx.date}</Text>
                    </View>
                    <Text style={[styles.txAmount, { color: tx.amount > 0 ? Colors.danger : Colors.success }]}>
                      {tx.amount > 0 ? '+' : ''}ETB {Math.abs(tx.amount).toLocaleString()}
                    </Text>
                  </View>
                ))}
              </Card>
            </ScrollView>
          </View>
        )}
      </Modal>

      {/* Add/Edit Form Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>
              {editing ? t('editCustomer') : t('addCustomerTitle')}
            </Text>
            <TouchableOpacity onPress={() => setShowForm(false)}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView style={{ padding: Spacing.md }} keyboardShouldPersistTaps="handled">
            <Input label={t('name')} value={form.name} onChangeText={(v) => setForm((p) => ({ ...p, name: v }))} placeholder="Full name" leftIcon={<User size={16} color={colors.textMuted} />} />
            <Input label={t('phone')} value={form.phone} onChangeText={(v) => setForm((p) => ({ ...p, phone: v }))} keyboardType="phone-pad" placeholder="+251..." leftIcon={<Phone size={16} color={colors.textMuted} />} />
            <Input label={t('email')} value={form.email} onChangeText={(v) => setForm((p) => ({ ...p, email: v }))} keyboardType="email-address" autoCapitalize="none" placeholder="email@example.com" leftIcon={<Mail size={16} color={colors.textMuted} />} />
            <Input label={t('address')} value={form.address} onChangeText={(v) => setForm((p) => ({ ...p, address: v }))} placeholder="City, Address" leftIcon={<MapPin size={16} color={colors.textMuted} />} />
            <Button title={t('save')} onPress={handleSave} style={{ marginBottom: Spacing.xxl }} />
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  headerTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  addBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  searchRow: { padding: Spacing.sm, borderBottomWidth: 1 },
  searchInput: { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, paddingHorizontal: Spacing.sm, height: 40, borderWidth: 1, gap: 8 },
  searchText: { flex: 1, fontSize: FontSize.sm },
  list: { padding: Spacing.sm, gap: Spacing.sm },
  customerRow: { flexDirection: 'row', alignItems: 'center', padding: Spacing.sm, borderRadius: Radius.md, borderWidth: 1, gap: Spacing.sm },
  avatar: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: FontSize.xl, fontWeight: '700' },
  customerInfo: { flex: 1 },
  customerName: { fontSize: FontSize.md, fontWeight: '600' },
  customerPhone: { fontSize: FontSize.sm, marginTop: 2 },
  customerPurchases: { fontSize: FontSize.xs, marginTop: 2 },
  customerRight: { alignItems: 'flex-end', gap: 4 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80, gap: 12 },
  emptyText: { fontSize: FontSize.md },
  modal: { flex: 1 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  detailHero: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  avatarLarge: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center' },
  avatarLargeText: { fontSize: FontSize.xxxl, fontWeight: '700' },
  detailName: { fontSize: FontSize.xl, fontWeight: '700' },
  detailCard: { margin: Spacing.md },
  infoRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, gap: Spacing.sm },
  infoText: { fontSize: FontSize.sm, flex: 1 },
  statsRow: { flexDirection: 'row', gap: Spacing.sm, paddingHorizontal: Spacing.md, marginBottom: Spacing.md },
  statMini: { flex: 1, alignItems: 'center' },
  statMiniValue: { fontSize: FontSize.lg, fontWeight: '700' },
  statMiniLabel: { fontSize: FontSize.xs, marginTop: 4 },
  sectionTitle: { fontSize: FontSize.lg, fontWeight: '700', paddingHorizontal: Spacing.md, marginBottom: Spacing.sm },
  txRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: Spacing.sm },
  txNote: { fontSize: FontSize.sm, fontWeight: '500' },
  txDate: { fontSize: FontSize.xs, marginTop: 2 },
  txAmount: { fontSize: FontSize.sm, fontWeight: '700' },
});
