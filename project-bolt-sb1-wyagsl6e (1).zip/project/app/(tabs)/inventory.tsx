import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Plus, Eye, Edit2, Trash2, X, Package, TrendingUp, TrendingDown, ArrowLeftRight, SlidersHorizontal } from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const DEMO_PRODUCTS = [
  { id: 1, name: 'Samsung TV 55"', sku: 'SAM-TV-55', stock: 12, price: 3000, purchasePrice: 2400, category: 'Electronics' },
  { id: 2, name: 'iPhone 15 Pro', sku: 'APL-IP15P', stock: 2, price: 6000, purchasePrice: 4800, category: 'Electronics' },
  { id: 3, name: 'Nike Air Max 90', sku: 'NIK-AM90', stock: 30, price: 1500, purchasePrice: 900, category: 'Footwear' },
  { id: 4, name: 'Sony WH-1000XM5', sku: 'SNY-WH5', stock: 8, price: 1800, purchasePrice: 1300, category: 'Electronics' },
  { id: 5, name: 'Adidas Ultraboost', sku: 'ADI-UB22', stock: 0, price: 1200, purchasePrice: 800, category: 'Footwear' },
  { id: 6, name: 'Coffee Maker Pro', sku: 'CFM-PRO', stock: 15, price: 800, purchasePrice: 500, category: 'Appliances' },
];

const STOCK_HISTORY = [
  { type: 'in', qty: 20, date: '2025-06-01', note: 'Purchase Order #45' },
  { type: 'out', qty: 5, date: '2025-05-28', note: 'Sale #102' },
  { type: 'in', qty: 10, date: '2025-05-20', note: 'Stock Transfer' },
  { type: 'out', qty: 3, date: '2025-05-15', note: 'Sale #98' },
];

export default function InventoryScreen() {
  const { colors, t } = useTheme();
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState(DEMO_PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<typeof DEMO_PRODUCTS[0] | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showStockModal, setShowStockModal] = useState(false);
  const [stockAction, setStockAction] = useState<'in' | 'out' | 'transfer' | 'adjust'>('in');
  const [stockQty, setStockQty] = useState('');
  const [stockNote, setStockNote] = useState('');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({ name: '', sku: '', price: '', purchasePrice: '', stock: '', category: '' });

  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase())
  );

  const handleStockAction = () => {
    if (!stockQty || isNaN(Number(stockQty))) {
      Alert.alert('Error', 'Please enter a valid quantity');
      return;
    }
    const qty = Number(stockQty);
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id !== selectedProduct?.id) return p;
        let newStock = p.stock;
        if (stockAction === 'in') newStock += qty;
        else if (stockAction === 'out') newStock = Math.max(0, newStock - qty);
        else if (stockAction === 'adjust') newStock = qty;
        return { ...p, stock: newStock };
      })
    );
    setShowStockModal(false);
    setStockQty('');
    setStockNote('');
    Alert.alert('Success', `Stock ${stockAction} recorded successfully`);
  };

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.sku) { Alert.alert('Error', 'Name and SKU are required'); return; }
    const p = {
      id: products.length + 1,
      name: newProduct.name,
      sku: newProduct.sku,
      price: Number(newProduct.price) || 0,
      purchasePrice: Number(newProduct.purchasePrice) || 0,
      stock: Number(newProduct.stock) || 0,
      category: newProduct.category || 'General',
    };
    setProducts((prev) => [p, ...prev]);
    setShowAddProduct(false);
    setNewProduct({ name: '', sku: '', price: '', purchasePrice: '', stock: '', category: '' });
  };

  const getStockBadge = (stock: number) => {
    if (stock === 0) return <Badge label="Out of Stock" variant="danger" />;
    if (stock < 5) return <Badge label="Low Stock" variant="warning" />;
    return <Badge label="In Stock" variant="success" />;
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={[styles.header, { backgroundColor: colors.header, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('inventory')}</Text>
        <TouchableOpacity onPress={() => setShowAddProduct(true)} style={[styles.addBtn, { backgroundColor: Colors.primary }]}>
          <Plus size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={[styles.searchRow, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View style={[styles.searchInput, { backgroundColor: colors.input, borderColor: colors.border }]}>
          <Search size={16} color={colors.textMuted} />
          <TextInput
            style={[styles.searchText, { color: colors.text }]}
            placeholder="Search products..."
            placeholderTextColor={colors.textMuted}
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.productRow, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => { setSelectedProduct(item); setShowDetail(true); }}
          >
            <View style={[styles.productIcon, { backgroundColor: colors.surfaceSecondary }]}>
              <Package size={24} color={Colors.primary} />
            </View>
            <View style={styles.productInfo}>
              <Text style={[styles.productName, { color: colors.text }]}>{item.name}</Text>
              <Text style={[styles.productSku, { color: colors.textMuted }]}>{item.sku}</Text>
              <View style={styles.productMeta}>
                {getStockBadge(item.stock)}
                <Text style={[styles.stockQty, { color: colors.textSecondary }]}>Qty: {item.stock}</Text>
              </View>
            </View>
            <View style={styles.productPrices}>
              <Text style={[styles.sellingPrice, { color: Colors.primary }]}>ETB {item.price.toLocaleString()}</Text>
              <Text style={[styles.purchasePrice, { color: colors.textMuted }]}>Cost: {item.purchasePrice.toLocaleString()}</Text>
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Package size={48} color={colors.textMuted} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t('noData')}</Text>
          </View>
        }
      />

      {/* Product Detail Modal */}
      <Modal visible={showDetail} animationType="slide" presentationStyle="pageSheet">
        {selectedProduct && (
          <View style={[styles.modal, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>{t('productDetails')}</Text>
              <TouchableOpacity onPress={() => setShowDetail(false)}>
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.detailContent}>
              <View style={[styles.detailHero, { backgroundColor: colors.surfaceSecondary }]}>
                <Package size={64} color={Colors.primary} />
              </View>

              <Card style={styles.detailCard}>
                {[
                  [t('productName'), selectedProduct.name],
                  [t('sku'), selectedProduct.sku],
                  [t('category'), selectedProduct.category],
                  [t('sellingPrice'), `ETB ${selectedProduct.price.toLocaleString()}`],
                  [t('purchasePrice'), `ETB ${selectedProduct.purchasePrice.toLocaleString()}`],
                  [t('currentStock'), String(selectedProduct.stock)],
                ].map(([label, value]) => (
                  <View key={label} style={[styles.detailRow, { borderBottomColor: colors.divider }]}>
                    <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>{label}</Text>
                    <Text style={[styles.detailValue, { color: colors.text }]}>{value}</Text>
                  </View>
                ))}
              </Card>

              {/* Stock Actions */}
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Stock Management</Text>
              <View style={styles.stockActions}>
                {([
                  { action: 'in' as const, label: t('stockIn'), icon: <TrendingUp size={16} color="#fff" />, color: Colors.success },
                  { action: 'out' as const, label: t('stockOut'), icon: <TrendingDown size={16} color="#fff" />, color: Colors.danger },
                  { action: 'transfer' as const, label: t('transferStock'), icon: <ArrowLeftRight size={16} color="#fff" />, color: Colors.warning },
                  { action: 'adjust' as const, label: t('adjustStock'), icon: <SlidersHorizontal size={16} color="#fff" />, color: Colors.secondary },
                ] as const).map((item) => (
                  <TouchableOpacity
                    key={item.action}
                    style={[styles.stockActionBtn, { backgroundColor: item.color }]}
                    onPress={() => {
                      setStockAction(item.action);
                      setShowStockModal(true);
                    }}
                  >
                    {item.icon}
                    <Text style={styles.stockActionText}>{item.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Stock History */}
              <Text style={[styles.sectionTitle, { color: colors.text }]}>{t('stockHistory')}</Text>
              <Card>
                {STOCK_HISTORY.map((h, i) => (
                  <View key={i} style={[styles.historyRow, i < STOCK_HISTORY.length - 1 && { borderBottomColor: colors.divider, borderBottomWidth: 1 }]}>
                    <View style={[styles.historyIcon, { backgroundColor: h.type === 'in' ? '#D1FAE5' : '#FEE2E2' }]}>
                      {h.type === 'in'
                        ? <TrendingUp size={14} color={Colors.success} />
                        : <TrendingDown size={14} color={Colors.danger} />}
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.historyNote, { color: colors.text }]}>{h.note}</Text>
                      <Text style={[styles.historyDate, { color: colors.textMuted }]}>{h.date}</Text>
                    </View>
                    <Text style={[styles.historyQty, { color: h.type === 'in' ? Colors.success : Colors.danger }]}>
                      {h.type === 'in' ? '+' : '-'}{h.qty}
                    </Text>
                  </View>
                ))}
              </Card>
            </ScrollView>
          </View>
        )}
      </Modal>

      {/* Stock Action Modal */}
      <Modal visible={showStockModal} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>
              {stockAction === 'in' ? t('stockIn') : stockAction === 'out' ? t('stockOut') : stockAction === 'transfer' ? t('transferStock') : t('adjustStock')}
            </Text>
            <TouchableOpacity onPress={() => setShowStockModal(false)}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          <View style={styles.stockModalContent}>
            <Input label={t('quantity')} value={stockQty} onChangeText={setStockQty} keyboardType="numeric" placeholder="0" />
            <Input label="Note" value={stockNote} onChangeText={setStockNote} placeholder="Optional note..." />
            <Button title="Confirm" onPress={handleStockAction} />
          </View>
        </View>
      </Modal>

      {/* Add Product Modal */}
      <Modal visible={showAddProduct} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t('addProduct')}</Text>
            <TouchableOpacity onPress={() => setShowAddProduct(false)}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.stockModalContent} keyboardShouldPersistTaps="handled">
            <Input label={t('productName')} value={newProduct.name} onChangeText={(v) => setNewProduct((p) => ({ ...p, name: v }))} placeholder="Product name" />
            <Input label={t('sku')} value={newProduct.sku} onChangeText={(v) => setNewProduct((p) => ({ ...p, sku: v }))} placeholder="SKU-001" />
            <Input label={t('sellingPrice')} value={newProduct.price} onChangeText={(v) => setNewProduct((p) => ({ ...p, price: v }))} keyboardType="numeric" placeholder="0.00" />
            <Input label={t('purchasePrice')} value={newProduct.purchasePrice} onChangeText={(v) => setNewProduct((p) => ({ ...p, purchasePrice: v }))} keyboardType="numeric" placeholder="0.00" />
            <Input label={t('stockQty')} value={newProduct.stock} onChangeText={(v) => setNewProduct((p) => ({ ...p, stock: v }))} keyboardType="numeric" placeholder="0" />
            <Input label={t('category')} value={newProduct.category} onChangeText={(v) => setNewProduct((p) => ({ ...p, category: v }))} placeholder="Electronics" />
            <Button title={t('save')} onPress={handleAddProduct} style={{ marginBottom: Spacing.xxl }} />
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  headerTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  addBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  searchRow: { padding: Spacing.sm, borderBottomWidth: 1 },
  searchInput: { flexDirection: 'row', alignItems: 'center', borderRadius: Radius.md, paddingHorizontal: Spacing.sm, height: 40, borderWidth: 1, gap: 8 },
  searchText: { flex: 1, fontSize: FontSize.sm },
  list: { padding: Spacing.sm, gap: Spacing.sm },
  productRow: { flexDirection: 'row', alignItems: 'center', padding: Spacing.sm, borderRadius: Radius.md, borderWidth: 1, gap: Spacing.sm },
  productIcon: { width: 56, height: 56, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  productInfo: { flex: 1 },
  productName: { fontSize: FontSize.sm, fontWeight: '600' },
  productSku: { fontSize: FontSize.xs, marginTop: 2 },
  productMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  stockQty: { fontSize: FontSize.xs },
  productPrices: { alignItems: 'flex-end' },
  sellingPrice: { fontSize: FontSize.sm, fontWeight: '700' },
  purchasePrice: { fontSize: FontSize.xs, marginTop: 2 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80, gap: 12 },
  emptyText: { fontSize: FontSize.md },
  modal: { flex: 1 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  detailContent: { flex: 1 },
  detailHero: { height: 160, alignItems: 'center', justifyContent: 'center' },
  detailCard: { margin: Spacing.md },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: Spacing.sm, borderBottomWidth: 1 },
  detailLabel: { fontSize: FontSize.sm },
  detailValue: { fontSize: FontSize.sm, fontWeight: '600' },
  sectionTitle: { fontSize: FontSize.lg, fontWeight: '700', paddingHorizontal: Spacing.md, marginTop: Spacing.md, marginBottom: Spacing.sm },
  stockActions: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, paddingHorizontal: Spacing.md, marginBottom: Spacing.md },
  stockActionBtn: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: 10, borderRadius: Radius.md, gap: 6 },
  stockActionText: { color: '#fff', fontSize: FontSize.sm, fontWeight: '600' },
  historyRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, gap: Spacing.sm },
  historyIcon: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  historyNote: { fontSize: FontSize.sm, fontWeight: '500' },
  historyDate: { fontSize: FontSize.xs, marginTop: 2 },
  historyQty: { fontSize: FontSize.md, fontWeight: '700' },
  stockModalContent: { padding: Spacing.md },
});
