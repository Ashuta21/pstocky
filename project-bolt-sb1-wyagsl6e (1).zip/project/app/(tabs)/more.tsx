import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Truck,
  ShoppingBag,
  BarChart2,
  Store,
  CreditCard,
  Bell,
  User,
  Settings,
  ChevronRight,
  LogOut,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const sections = [
  {
    title: 'Management',
    items: [
      { label: 'Suppliers', icon: Truck, route: '/suppliers', color: Colors.warning },
      { label: 'Purchases', icon: ShoppingBag, route: '/purchases', color: Colors.secondary },
      { label: 'Reports', icon: BarChart2, route: '/reports-full', color: '#EC4899' },
    ],
  },
  {
    title: 'Store',
    items: [
      { label: 'Multi-Store', icon: Store, route: '/stores', color: Colors.primary },
      { label: 'Subscription', icon: CreditCard, route: '/subscription', color: Colors.success },
    ],
  },
  {
    title: 'Account',
    items: [
      { label: 'Notifications', icon: Bell, route: '/notifications', color: Colors.warning },
      { label: 'Profile', icon: User, route: '/profile', color: Colors.secondary },
      { label: 'Settings', icon: Settings, route: '/settings', color: '#64748B' },
    ],
  },
];

export default function MoreScreen() {
  const { colors, t } = useTheme();
  const { user, logout } = useAppStore();

  const handleLogout = () => {
    logout();
    router.replace('/login');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={[styles.header, { backgroundColor: colors.header, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>More</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* User Card */}
        <View style={[styles.userCard, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <View style={[styles.avatar, { backgroundColor: Colors.primary + '22' }]}>
            <Text style={[styles.avatarText, { color: Colors.primary }]}>
              {(user?.name ?? 'D').charAt(0).toUpperCase()}
            </Text>
          </View>
          <View style={styles.userInfo}>
            <Text style={[styles.userName, { color: colors.text }]}>{user?.name ?? 'Demo User'}</Text>
            <Text style={[styles.userEmail, { color: colors.textSecondary }]}>{user?.email ?? 'demo@pstocky.com'}</Text>
            {user?.company && (
              <Text style={[styles.userCompany, { color: colors.textMuted }]}>{user.company}</Text>
            )}
          </View>
          <TouchableOpacity onPress={() => router.push('/profile')}>
            <ChevronRight size={20} color={colors.textMuted} />
          </TouchableOpacity>
        </View>

        {sections.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{section.title.toUpperCase()}</Text>
            <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              {section.items.map((item, i) => (
                <TouchableOpacity
                  key={item.label}
                  style={[
                    styles.menuItem,
                    i < section.items.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.divider },
                  ]}
                  onPress={() => router.push(item.route as any)}
                >
                  <View style={[styles.menuIcon, { backgroundColor: item.color + '18' }]}>
                    <item.icon size={20} color={item.color} />
                  </View>
                  <Text style={[styles.menuLabel, { color: colors.text }]}>{item.label}</Text>
                  <ChevronRight size={16} color={colors.textMuted} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Logout */}
        <View style={[styles.section, { paddingBottom: Spacing.xxl }]}>
          <TouchableOpacity
            style={[styles.logoutBtn, { backgroundColor: Colors.danger + '18', borderColor: Colors.danger + '30' }]}
            onPress={handleLogout}
          >
            <LogOut size={20} color={Colors.danger} />
            <Text style={[styles.logoutText, { color: Colors.danger }]}>{t('logout')}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { padding: Spacing.md, borderBottomWidth: 1 },
  headerTitle: { fontSize: FontSize.xl, fontWeight: '700' },
  userCard: { flexDirection: 'row', alignItems: 'center', padding: Spacing.md, gap: Spacing.sm, borderBottomWidth: 1 },
  avatar: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: FontSize.xl, fontWeight: '700' },
  userInfo: { flex: 1 },
  userName: { fontSize: FontSize.md, fontWeight: '700' },
  userEmail: { fontSize: FontSize.sm, marginTop: 2 },
  userCompany: { fontSize: FontSize.xs, marginTop: 2 },
  section: { paddingHorizontal: Spacing.md, paddingTop: Spacing.md },
  sectionTitle: { fontSize: FontSize.xs, fontWeight: '700', marginBottom: Spacing.sm, letterSpacing: 0.5 },
  sectionCard: { borderRadius: Radius.lg, borderWidth: 1, overflow: 'hidden' },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: Spacing.md, gap: Spacing.sm },
  menuIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, fontSize: FontSize.md, fontWeight: '500' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: Spacing.md, borderRadius: Radius.lg, borderWidth: 1, gap: 8 },
  logoutText: { fontSize: FontSize.md, fontWeight: '600' },
});
