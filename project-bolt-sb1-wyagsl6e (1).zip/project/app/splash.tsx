import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Colors, FontSize } from '@/constants/theme';

const { width, height } = Dimensions.get('window');

export default function SplashScreen() {
  const logoScale = useRef(new Animated.Value(0.6)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const taglineOpacity = useRef(new Animated.Value(0)).current;
  const dotScale = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(logoScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
        Animated.timing(logoOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]),
      Animated.spring(dotScale, { toValue: 1, tension: 80, friction: 6, useNativeDriver: true }),
      Animated.timing(taglineOpacity, { toValue: 1, duration: 500, useNativeDriver: true }),
    ]).start();

    const timer = setTimeout(() => router.replace('/login'), 2800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <LinearGradient
      colors={['#0F172A', '#1E293B', '#0F172A']}
      style={styles.container}
    >
      <View style={styles.glowCircle} />
      <View style={styles.glowCircle2} />

      <Animated.View
        style={[styles.logoContainer, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}
      >
        <LinearGradient
          colors={[Colors.primary, Colors.secondary]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.logoBox}
        >
          <Text style={styles.logoLetter}>P</Text>
        </LinearGradient>
        <View style={styles.nameRow}>
          <Text style={styles.logoName}>PStocky</Text>
          <Animated.View style={[styles.dot, { transform: [{ scale: dotScale }] }]} />
        </View>
      </Animated.View>

      <Animated.Text style={[styles.tagline, { opacity: taglineOpacity }]}>
        Inventory & POS Management
      </Animated.Text>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Powered by PStocky</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  glowCircle: {
    position: 'absolute',
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: Colors.primary,
    opacity: 0.08,
    top: height * 0.1,
    left: -80,
  },
  glowCircle2: {
    position: 'absolute',
    width: 250,
    height: 250,
    borderRadius: 125,
    backgroundColor: Colors.secondary,
    opacity: 0.08,
    bottom: height * 0.1,
    right: -60,
  },
  logoContainer: { alignItems: 'center', marginBottom: 24 },
  logoBox: {
    width: 88,
    height: 88,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 12,
  },
  logoLetter: {
    fontSize: 48,
    fontWeight: '800',
    color: '#fff',
  },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  logoName: {
    fontSize: FontSize.xxxl,
    fontWeight: '800',
    color: '#fff',
    letterSpacing: -0.5,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.primary,
    marginLeft: 4,
    marginTop: 8,
  },
  tagline: {
    fontSize: FontSize.md,
    color: 'rgba(255,255,255,0.55)',
    letterSpacing: 0.5,
  },
  footer: { position: 'absolute', bottom: 40 },
  footerText: { color: 'rgba(255,255,255,0.25)', fontSize: FontSize.xs },
});
