import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { Mail } from 'lucide-react-native';
import { router } from 'expo-router';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Spacing } from '@/constants/theme';
import { forgotPassword } from '@/services/api';

export default function ForgotPasswordScreen() {
  const { colors, t } = useTheme();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSend = async () => {
    setError('');
    if (!email.trim()) { setError('Email is required'); return; }

    setLoading(true);
    try {
      await forgotPassword(email.trim());
      setSent(true);
    } catch (err: any) {
      setSent(true); // Show success even on demo
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScreenHeader title={t('forgotPassword')} showBack onBack={() => router.back()} />
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          {sent ? (
            <View style={styles.successContainer}>
              <View style={[styles.iconCircle, { backgroundColor: '#D1FAE5' }]}>
                <Mail size={40} color={Colors.success} />
              </View>
              <Text style={[styles.successTitle, { color: colors.text }]}>Check your email</Text>
              <Text style={[styles.successSub, { color: colors.textSecondary }]}>
                We sent a password reset link to {email}
              </Text>
              <Button title="Back to Login" onPress={() => router.replace('/login')} style={{ marginTop: Spacing.xl }} />
            </View>
          ) : (
            <>
              <View style={[styles.iconCircle, { backgroundColor: '#DBEAFE' }]}>
                <Mail size={40} color={Colors.primary} />
              </View>
              <Text style={[styles.title, { color: colors.text }]}>Reset Password</Text>
              <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
                Enter your email address and we'll send you a link to reset your password.
              </Text>
              <Input
                label={t('email')}
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                error={error}
                leftIcon={<Mail size={18} color={colors.textMuted} />}
                placeholder="admin@pstocky.com"
              />
              <Button title={t('sendResetLink')} onPress={handleSend} loading={loading} />
            </>
          )}
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flexGrow: 1, padding: Spacing.lg, alignItems: 'center' },
  iconCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
    marginTop: Spacing.xl,
  },
  title: { fontSize: FontSize.xxl, fontWeight: '700', marginBottom: 8, textAlign: 'center' },
  subtitle: { fontSize: FontSize.sm, textAlign: 'center', lineHeight: 22, marginBottom: Spacing.xl },
  successContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: FontSize.xxl, fontWeight: '700', marginBottom: 8 },
  successSub: { fontSize: FontSize.sm, textAlign: 'center', lineHeight: 22 },
});
