import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { CheckCircle, CreditCard, Calendar, Clock } from 'lucide-react-native';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

const PLANS = [
  {
    name: 'Starter',
    price: 'ETB 299/mo',
    features: ['1 Store', '500 Products', '2 Users', 'Basic Reports', 'Email Support'],
    gradient: ['#64748B', '#475569'] as [string, string],
    recommended: false,
  },
  {
    name: 'Pro',
    price: 'ETB 799/mo',
    features: ['3 Stores', 'Unlimited Products', '5 Users', 'Advanced Reports', 'Priority Support', 'API Access'],
    gradient: [Colors.primary, Colors.secondary] as [string, string],
    recommended: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    features: ['Unlimited Stores', 'Unlimited Products', 'Unlimited Users', 'Custom Reports', '24/7 Support', 'Dedicated Manager'],
    gradient: ['#F59E0B', '#D97706'] as [string, string],
    recommended: false,
  },
];

export default function SubscriptionScreen() {
  const { colors, t } = useTheme();
  const currentPlan = 'Pro';
  const expiryDate = '2025-12-31';
  const remainingDays = 207;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader title={t('subscription')} showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>

        {/* Current Plan Card */}
        <LinearGradient colors={[Colors.primary, Colors.secondary]} style={styles.currentPlanCard}>
          <View style={styles.currentPlanTop}>
            <View>
              <Text style={styles.currentPlanLabel}>{t('currentPlan')}</Text>
              <Text style={styles.currentPlanName}>{currentPlan}</Text>
            </View>
            <CreditCard size={32} color="rgba(255,255,255,0.7)" />
          </View>
          <View style={styles.currentPlanInfo}>
            <View style={styles.infoChip}>
              <Calendar size={14} color="rgba(255,255,255,0.8)" />
              <Text style={styles.infoChipText}>{t('expiryDate')}: {expiryDate}</Text>
            </View>
            <View style={styles.infoChip}>
              <Clock size={14} color="rgba(255,255,255,0.8)" />
              <Text style={styles.infoChipText}>{remainingDays} {t('remainingDays')}</Text>
            </View>
          </View>
        </LinearGradient>

        <Text style={[styles.sectionTitle, { color: colors.text }]}>Available Plans</Text>

        {PLANS.map((plan) => (
          <View key={plan.name} style={[styles.planCard, { backgroundColor: colors.card, borderColor: plan.name === currentPlan ? Colors.primary : colors.border, borderWidth: plan.name === currentPlan ? 2 : 1 }]}>
            {plan.recommended && (
              <View style={[styles.recommendedBadge, { backgroundColor: Colors.primary }]}>
                <Text style={styles.recommendedText}>CURRENT PLAN</Text>
              </View>
            )}
            <LinearGradient colors={plan.gradient} style={styles.planHeader}>
              <Text style={styles.planName}>{plan.name}</Text>
              <Text style={styles.planPrice}>{plan.price}</Text>
            </LinearGradient>
            <View style={styles.planFeatures}>
              {plan.features.map((feature) => (
                <View key={feature} style={styles.featureRow}>
                  <CheckCircle size={16} color={Colors.success} />
                  <Text style={[styles.featureText, { color: colors.text }]}>{feature}</Text>
                </View>
              ))}
            </View>
            <Button
              title={plan.name === currentPlan ? 'Current Plan' : `Upgrade to ${plan.name}`}
              onPress={() => plan.name !== currentPlan && Alert.alert('Upgrade', `Upgrade to ${plan.name}?`)}
              variant={plan.name === currentPlan ? 'ghost' : 'primary'}
              disabled={plan.name === currentPlan}
              style={styles.planBtn}
            />
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: Spacing.md, paddingBottom: Spacing.xxl, gap: Spacing.md },
  currentPlanCard: { borderRadius: Radius.xl, padding: Spacing.lg },
  currentPlanTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.md },
  currentPlanLabel: { color: 'rgba(255,255,255,0.7)', fontSize: FontSize.sm, marginBottom: 4 },
  currentPlanName: { color: '#fff', fontSize: FontSize.xxl, fontWeight: '800' },
  currentPlanInfo: { gap: 8 },
  infoChip: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoChipText: { color: 'rgba(255,255,255,0.85)', fontSize: FontSize.sm },
  sectionTitle: { fontSize: FontSize.xl, fontWeight: '700', marginTop: Spacing.sm },
  planCard: { borderRadius: Radius.xl, overflow: 'hidden' },
  recommendedBadge: { paddingHorizontal: Spacing.md, paddingVertical: 4, alignSelf: 'flex-end', margin: Spacing.sm, borderRadius: Radius.full },
  recommendedText: { color: '#fff', fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
  planHeader: { padding: Spacing.lg },
  planName: { color: '#fff', fontSize: FontSize.xl, fontWeight: '800', marginBottom: 4 },
  planPrice: { color: 'rgba(255,255,255,0.9)', fontSize: FontSize.lg, fontWeight: '600' },
  planFeatures: { padding: Spacing.md, gap: Spacing.sm },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  featureText: { fontSize: FontSize.sm },
  planBtn: { margin: Spacing.md, marginTop: 0 },
});
