import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Mail, Lock, Fingerprint, ChevronRight } from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { login, TokenManager } from '@/services/api';
import { SecureStorage, Preferences } from '@/services/storage';
import * as LocalAuthentication from 'expo-local-authentication';

export default function LoginScreen() {
  const { colors, isDark, t } = useTheme();
  const { setToken, setUser } = useAppStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [passError, setPassError] = useState('');

  const handleLogin = async () => {
    setEmailError('');
    setPassError('');
    if (!email.trim()) { setEmailError('Email is required'); return; }
    if (!password.trim()) { setPassError('Password is required'); return; }

    setLoading(true);
    try {
      const res = await login(email.trim(), password);
      TokenManager.setToken(res.token);
      if (res.refresh_token) TokenManager.setRefreshToken(res.refresh_token);
      await SecureStorage.setToken(res.token);
      if (res.refresh_token) await SecureStorage.setRefreshToken(res.refresh_token);
      if (remember) await Preferences.save({ rememberedEmail: email.trim() });
      setToken(res.token);
      setUser(res.user);
      router.replace('/(tabs)');
    } catch (err: any) {
      Alert.alert('Login Failed', err.message || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  const handleBiometric = async () => {
    const compatible = await LocalAuthentication.hasHardwareAsync();
    const enrolled = await LocalAuthentication.isEnrolledAsync();
    if (!compatible || !enrolled) {
      Alert.alert('Biometric Unavailable', 'No fingerprint or face ID enrolled on this device.');
      return;
    }
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Sign in to PStocky',
      fallbackLabel: 'Use Password',
      cancelLabel: 'Cancel',
      disableDeviceFallback: false,
    });
    if (result.success) {
      const storedToken = await SecureStorage.getToken();
      if (storedToken) {
        TokenManager.setToken(storedToken);
        setToken(storedToken);
        router.replace('/(tabs)');
      } else {
        Alert.alert('No saved session', 'Please log in with your password first.');
      }
    }
  };

  const handleDemo = () => {
    setToken('demo-token');
    setUser({ name: 'Demo User', email: 'demo@pstocky.com', company: 'PStocky Demo' });
    router.replace('/(tabs)');
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={{ flex: 1, backgroundColor: colors.background }}
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <LinearGradient
          colors={['#0F172A', '#1E3A5F']}
          style={styles.headerGradient}
        >
          <View style={styles.logoBox}>
            <LinearGradient
              colors={[Colors.primary, Colors.secondary]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.logoInner}
            >
              <Text style={styles.logoLetter}>P</Text>
            </LinearGradient>
          </View>
          <Text style={styles.appName}>PStocky</Text>
          <Text style={styles.tagline}>{t('tagline')}</Text>
        </LinearGradient>

        {/* Form */}
        <View style={[styles.form, { backgroundColor: colors.surface }]}>
          <Text style={[styles.formTitle, { color: colors.text }]}>
            Welcome back
          </Text>
          <Text style={[styles.formSubtitle, { color: colors.textSecondary }]}>
            Sign in to your account
          </Text>

          <Input
            label={t('email')}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            error={emailError}
            leftIcon={<Mail size={18} color={colors.textMuted} />}
            placeholder="admin@pstocky.com"
          />

          <Input
            label={t('password')}
            value={password}
            onChangeText={setPassword}
            isPassword
            error={passError}
            leftIcon={<Lock size={18} color={colors.textMuted} />}
            placeholder="••••••••"
          />

          <View style={styles.rememberRow}>
            <View style={styles.rememberLeft}>
              <Switch
                value={remember}
                onValueChange={setRemember}
                trackColor={{ false: colors.border, true: Colors.primary }}
                thumbColor="#fff"
              />
              <Text style={[styles.rememberText, { color: colors.textSecondary }]}>
                {t('rememberMe')}
              </Text>
            </View>
            <TouchableOpacity onPress={() => router.push('/forgot-password')}>
              <Text style={styles.forgotText}>{t('forgotPassword')}</Text>
            </TouchableOpacity>
          </View>

          <Button
            title={t('login')}
            onPress={handleLogin}
            loading={loading}
            style={styles.loginBtn}
          />

          <View style={styles.dividerRow}>
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
            <Text style={[styles.dividerText, { color: colors.textMuted }]}>or</Text>
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
          </View>

          <TouchableOpacity
            style={[styles.biometricBtn, { borderColor: colors.border, backgroundColor: colors.input }]}
            onPress={handleBiometric}
          >
            <Fingerprint size={22} color={Colors.primary} />
            <Text style={[styles.biometricText, { color: colors.text }]}>
              {t('biometricLogin')}
            </Text>
            <ChevronRight size={16} color={colors.textMuted} />
          </TouchableOpacity>

          <TouchableOpacity onPress={handleDemo} style={styles.demoBtn}>
            <Text style={[styles.demoText, { color: Colors.primary }]}>
              Continue with Demo Account
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll: { flexGrow: 1 },
  headerGradient: {
    paddingTop: 64,
    paddingBottom: 40,
    alignItems: 'center',
  },
  logoBox: { marginBottom: 12 },
  logoInner: {
    width: 72,
    height: 72,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoLetter: { fontSize: 38, fontWeight: '800', color: '#fff' },
  appName: { fontSize: FontSize.xxl, fontWeight: '800', color: '#fff', letterSpacing: -0.5 },
  tagline: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.6)', marginTop: 4 },
  form: {
    flex: 1,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    marginTop: -20,
    padding: Spacing.lg,
    paddingTop: Spacing.xl,
    minHeight: 500,
  },
  formTitle: { fontSize: FontSize.xxl, fontWeight: '700', marginBottom: 4 },
  formSubtitle: { fontSize: FontSize.sm, marginBottom: Spacing.lg },
  rememberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.lg,
  },
  rememberLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  rememberText: { fontSize: FontSize.sm },
  forgotText: { color: Colors.primary, fontSize: FontSize.sm, fontWeight: '600' },
  loginBtn: { marginBottom: Spacing.md },
  dividerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.md },
  divider: { flex: 1, height: 1 },
  dividerText: { marginHorizontal: 12, fontSize: FontSize.sm },
  biometricBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: 10,
    marginBottom: Spacing.md,
  },
  biometricText: { flex: 1, fontSize: FontSize.md, fontWeight: '500' },
  demoBtn: { alignItems: 'center', paddingVertical: Spacing.sm },
  demoText: { fontSize: FontSize.sm, fontWeight: '600' },
});
