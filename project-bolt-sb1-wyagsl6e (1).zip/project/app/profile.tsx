import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Camera, Lock, X } from 'lucide-react-native';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card } from '@/components/ui/Card';
import { ScreenHeader } from '@/components/ui/ScreenHeader';
import { useTheme } from '@/hooks/useTheme';
import { useAppStore } from '@/store';
import { Colors, FontSize, Radius, Spacing } from '@/constants/theme';

export default function ProfileScreen() {
  const { colors, t } = useTheme();
  const { user, setUser } = useAppStore();
  const [showPassModal, setShowPassModal] = useState(false);
  const [form, setForm] = useState({
    name: user?.name ?? '',
    email: user?.email ?? '',
    phone: user?.phone ?? '',
    company: user?.company ?? '',
  });
  const [passForm, setPassForm] = useState({ current: '', newPass: '', confirm: '' });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    setUser({ ...user, ...form });
    setSaving(false);
    Alert.alert('Success', 'Profile updated successfully');
  };

  const handleChangePass = () => {
    if (!passForm.current || !passForm.newPass || !passForm.confirm) {
      Alert.alert('Error', 'All fields are required');
      return;
    }
    if (passForm.newPass !== passForm.confirm) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }
    Alert.alert('Success', 'Password changed successfully');
    setShowPassModal(false);
    setPassForm({ current: '', newPass: '', confirm: '' });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <ScreenHeader title={t('profile')} showBack />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Avatar */}
        <View style={[styles.avatarSection, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <View style={[styles.avatarWrap, { backgroundColor: Colors.primary + '22' }]}>
            <Text style={[styles.avatarText, { color: Colors.primary }]}>
              {(form.name || 'U').charAt(0).toUpperCase()}
            </Text>
          </View>
          <TouchableOpacity style={[styles.cameraBtn, { backgroundColor: Colors.primary }]}>
            <Camera size={14} color="#fff" />
          </TouchableOpacity>
          <Text style={[styles.avatarName, { color: colors.text }]}>{form.name}</Text>
          <Text style={[styles.avatarEmail, { color: colors.textSecondary }]}>{form.email}</Text>
        </View>

        <View style={styles.body}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>PERSONAL INFORMATION</Text>
          <Card>
            <Input label={t('userName')} value={form.name} onChangeText={(v) => setForm((p) => ({ ...p, name: v }))} placeholder="Full name" />
            <Input label={t('email')} value={form.email} onChangeText={(v) => setForm((p) => ({ ...p, email: v }))} keyboardType="email-address" autoCapitalize="none" />
            <Input label={t('phone')} value={form.phone} onChangeText={(v) => setForm((p) => ({ ...p, phone: v }))} keyboardType="phone-pad" />
            <Input label={t('companyName')} value={form.company} onChangeText={(v) => setForm((p) => ({ ...p, company: v }))} />
          </Card>

          <Button title="Save Changes" onPress={handleSave} loading={saving} style={{ marginTop: Spacing.md }} />

          <Text style={[styles.sectionTitle, { color: colors.textSecondary, marginTop: Spacing.lg }]}>SECURITY</Text>
          <Card>
            <TouchableOpacity style={styles.menuItem} onPress={() => setShowPassModal(true)}>
              <View style={[styles.menuIcon, { backgroundColor: Colors.primary + '18' }]}>
                <Lock size={18} color={Colors.primary} />
              </View>
              <Text style={[styles.menuLabel, { color: colors.text }]}>{t('changePassword')}</Text>
            </TouchableOpacity>
          </Card>
        </View>
      </ScrollView>

      {/* Change Password Modal */}
      <Modal visible={showPassModal} animationType="slide" presentationStyle="pageSheet">
        <View style={[styles.modal, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{t('changePassword')}</Text>
            <TouchableOpacity onPress={() => setShowPassModal(false)}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          <View style={{ padding: Spacing.md }}>
            <Input label={t('currentPassword')} value={passForm.current} onChangeText={(v) => setPassForm((p) => ({ ...p, current: v }))} isPassword />
            <Input label={t('newPassword')} value={passForm.newPass} onChangeText={(v) => setPassForm((p) => ({ ...p, newPass: v }))} isPassword />
            <Input label={t('confirmPassword')} value={passForm.confirm} onChangeText={(v) => setPassForm((p) => ({ ...p, confirm: v }))} isPassword />
            <Button title={t('save')} onPress={handleChangePass} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  avatarSection: { alignItems: 'center', paddingVertical: Spacing.xl, borderBottomWidth: 1, position: 'relative' },
  avatarWrap: { width: 88, height: 88, borderRadius: 44, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  cameraBtn: { position: 'absolute', bottom: Spacing.xl + 24, right: '35%', width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  avatarText: { fontSize: FontSize.xxxl, fontWeight: '700' },
  avatarName: { fontSize: FontSize.xl, fontWeight: '700', marginBottom: 4 },
  avatarEmail: { fontSize: FontSize.sm },
  body: { padding: Spacing.md },
  sectionTitle: { fontSize: FontSize.xs, fontWeight: '700', letterSpacing: 0.5, marginBottom: Spacing.sm },
  menuItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, gap: Spacing.sm },
  menuIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, fontSize: FontSize.md, fontWeight: '500' },
  modal: { flex: 1 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderBottomWidth: 1 },
  modalTitle: { fontSize: FontSize.xl, fontWeight: '700' },
});
