export const Colors = {
  primary: '#3B82F6',
  secondary: '#8B5CF6',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  lightBg: '#F4F6FA',
  darkBg: '#0F172A',

  light: {
    background: '#F4F6FA',
    surface: '#FFFFFF',
    surfaceSecondary: '#F1F5F9',
    border: '#E2E8F0',
    text: '#0F172A',
    textSecondary: '#64748B',
    textMuted: '#94A3B8',
    card: '#FFFFFF',
    cardShadow: 'rgba(0,0,0,0.08)',
    tabBar: '#FFFFFF',
    header: '#FFFFFF',
    input: '#F8FAFC',
    divider: '#E2E8F0',
  },
  dark: {
    background: '#0F172A',
    surface: '#1E293B',
    surfaceSecondary: '#162032',
    border: '#334155',
    text: '#F8FAFC',
    textSecondary: '#94A3B8',
    textMuted: '#64748B',
    card: '#1E293B',
    cardShadow: 'rgba(0,0,0,0.4)',
    tabBar: '#1E293B',
    header: '#1E293B',
    input: '#0F172A',
    divider: '#334155',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const FontSize = {
  xs: 11,
  sm: 13,
  md: 15,
  lg: 17,
  xl: 20,
  xxl: 24,
  xxxl: 30,
};
