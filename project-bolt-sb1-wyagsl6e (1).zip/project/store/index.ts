import { create } from 'zustand';

export type Theme = 'light' | 'dark';
export type Language = 'en' | 'am';

interface AppStore {
  theme: Theme;
  language: Language;
  token: string | null;
  user: any | null;
  currentStore: any | null;
  stores: any[];
  notifications: any[];
  isOnline: boolean;
  setTheme: (theme: Theme) => void;
  setLanguage: (lang: Language) => void;
  setToken: (token: string | null) => void;
  setUser: (user: any) => void;
  setCurrentStore: (store: any) => void;
  setStores: (stores: any[]) => void;
  setNotifications: (notifs: any[]) => void;
  setOnline: (online: boolean) => void;
  logout: () => void;
}

export const useAppStore = create<AppStore>((set) => ({
  theme: 'light',
  language: 'en',
  token: null,
  user: null,
  currentStore: null,
  stores: [],
  notifications: [],
  isOnline: true,

  setTheme: (theme) => {
    set({ theme });
    // Persist async — import lazily to avoid circular dep at module load time
    import('@/services/storage').then(({ Preferences }) =>
      Preferences.save({ theme })
    );
  },

  setLanguage: (language) => {
    set({ language });
    import('@/services/storage').then(({ Preferences }) =>
      Preferences.save({ language })
    );
  },

  setToken: (token) => set({ token }),

  setUser: (user) => set({ user }),

  setCurrentStore: (currentStore) => set({ currentStore }),

  setStores: (stores) => set({ stores }),

  setNotifications: (notifications) => set({ notifications }),

  setOnline: (isOnline) => set({ isOnline }),

  logout: () => {
    import('@/services/storage').then(({ SecureStorage }) =>
      SecureStorage.clearTokens()
    );
    set({ token: null, user: null, currentStore: null });
  },
}));
