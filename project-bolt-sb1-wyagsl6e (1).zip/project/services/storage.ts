/**
 * Secure token storage using expo-secure-store with AsyncStorage fallback.
 * SecureStore uses Android Keystore / iOS Keychain for hardware-backed encryption.
 */
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { API_CONFIG } from '@/config/api';

const SECURE_STORE_AVAILABLE = Platform.OS !== 'web';

export const SecureStorage = {
  async setToken(token: string): Promise<void> {
    if (SECURE_STORE_AVAILABLE) {
      await SecureStore.setItemAsync(API_CONFIG.TOKEN_KEY, token);
    } else {
      await AsyncStorage.setItem(API_CONFIG.TOKEN_KEY, token);
    }
  },

  async getToken(): Promise<string | null> {
    if (SECURE_STORE_AVAILABLE) {
      return SecureStore.getItemAsync(API_CONFIG.TOKEN_KEY);
    }
    return AsyncStorage.getItem(API_CONFIG.TOKEN_KEY);
  },

  async setRefreshToken(token: string): Promise<void> {
    if (SECURE_STORE_AVAILABLE) {
      await SecureStore.setItemAsync(API_CONFIG.REFRESH_TOKEN_KEY, token);
    } else {
      await AsyncStorage.setItem(API_CONFIG.REFRESH_TOKEN_KEY, token);
    }
  },

  async getRefreshToken(): Promise<string | null> {
    if (SECURE_STORE_AVAILABLE) {
      return SecureStore.getItemAsync(API_CONFIG.REFRESH_TOKEN_KEY);
    }
    return AsyncStorage.getItem(API_CONFIG.REFRESH_TOKEN_KEY);
  },

  async clearTokens(): Promise<void> {
    if (SECURE_STORE_AVAILABLE) {
      await SecureStore.deleteItemAsync(API_CONFIG.TOKEN_KEY);
      await SecureStore.deleteItemAsync(API_CONFIG.REFRESH_TOKEN_KEY);
    } else {
      await AsyncStorage.multiRemove([API_CONFIG.TOKEN_KEY, API_CONFIG.REFRESH_TOKEN_KEY]);
    }
  },
};

// ---------------------------------------------------------------------------
// General app preferences (theme, language, remembered email, etc.)
// ---------------------------------------------------------------------------
const PREFS_KEY = 'pstocky_prefs';

interface AppPreferences {
  theme: 'light' | 'dark';
  language: 'en' | 'am';
  rememberedEmail?: string;
}

export const Preferences = {
  async load(): Promise<Partial<AppPreferences>> {
    try {
      const raw = await AsyncStorage.getItem(PREFS_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  },

  async save(prefs: Partial<AppPreferences>): Promise<void> {
    try {
      const existing = await Preferences.load();
      await AsyncStorage.setItem(PREFS_KEY, JSON.stringify({ ...existing, ...prefs }));
    } catch {
      // ignore storage errors silently
    }
  },
};

// ---------------------------------------------------------------------------
// Offline request queue — simple pending-requests list in AsyncStorage
// ---------------------------------------------------------------------------
const OFFLINE_QUEUE_KEY = 'pstocky_offline_queue';

interface OfflineRequest {
  id: string;
  method: string;
  path: string;
  body?: unknown;
  createdAt: number;
}

export const OfflineQueue = {
  async enqueue(method: string, path: string, body?: unknown): Promise<void> {
    const queue = await OfflineQueue.getAll();
    const item: OfflineRequest = {
      id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
      method,
      path,
      body,
      createdAt: Date.now(),
    };
    await AsyncStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify([...queue, item]));
  },

  async getAll(): Promise<OfflineRequest[]> {
    try {
      const raw = await AsyncStorage.getItem(OFFLINE_QUEUE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  async clear(): Promise<void> {
    await AsyncStorage.removeItem(OFFLINE_QUEUE_KEY);
  },

  async flush(send: (method: string, path: string, body?: unknown) => Promise<unknown>): Promise<void> {
    const queue = await OfflineQueue.getAll();
    if (queue.length === 0) return;
    const succeeded: string[] = [];
    for (const item of queue) {
      try {
        await send(item.method, item.path, item.body);
        succeeded.push(item.id);
      } catch {
        // Leave failed items in queue for next sync
      }
    }
    const remaining = queue.filter((q) => !succeeded.includes(q.id));
    await AsyncStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(remaining));
  },
};
