import { API_CONFIG } from '@/config/api';
import { useAppStore } from '@/store';

// ---------------------------------------------------------------------------
// Token helpers (SecureStore when available, falls back to in-memory)
// ---------------------------------------------------------------------------
let _token: string | null = null;
let _refreshToken: string | null = null;

export const TokenManager = {
  setToken(token: string | null) {
    _token = token;
    useAppStore.getState().setToken(token);
  },
  getToken() {
    return _token ?? useAppStore.getState().token;
  },
  setRefreshToken(token: string | null) {
    _refreshToken = token;
  },
  getRefreshToken() {
    return _refreshToken;
  },
  clear() {
    _token = null;
    _refreshToken = null;
  },
};

// ---------------------------------------------------------------------------
// Core request function with retry + token refresh
// ---------------------------------------------------------------------------
async function request<T = any>(
  method: string,
  path: string,
  body?: unknown,
  attempt = 0
): Promise<T> {
  const token = TokenManager.getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);

  let res: Response;
  try {
    res = await fetch(`${API_CONFIG.BASE_URL}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err: any) {
    clearTimeout(timeoutId);
    const isNetworkError = err.name === 'AbortError' || err.message === 'Network request failed';
    if (isNetworkError && attempt < API_CONFIG.MAX_RETRIES) {
      await sleep(API_CONFIG.RETRY_DELAY * Math.pow(2, attempt));
      return request(method, path, body, attempt + 1);
    }
    throw new ApiError('Network error. Please check your connection.', 0);
  }
  clearTimeout(timeoutId);

  // Token expired — attempt refresh
  if (res.status === 401 && attempt === 0) {
    const refreshed = await attemptTokenRefresh();
    if (refreshed) return request(method, path, body, 1);
    useAppStore.getState().logout();
    throw new ApiError('Session expired. Please log in again.', 401);
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new ApiError(
      data?.message ?? data?.error ?? `Request failed (${res.status})`,
      res.status,
      data
    );
  }

  return data as T;
}

async function attemptTokenRefresh(): Promise<boolean> {
  const refreshToken = TokenManager.getRefreshToken();
  if (!refreshToken) return false;
  try {
    const res = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.REFRESH_TOKEN}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    const data = await res.json();
    if (res.ok && data.token) {
      TokenManager.setToken(data.token);
      if (data.refresh_token) TokenManager.setRefreshToken(data.refresh_token);
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

// ---------------------------------------------------------------------------
// Custom error class
// ---------------------------------------------------------------------------
export class ApiError extends Error {
  constructor(
    message: string,
    public statusCode: number,
    public data?: unknown
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// ---------------------------------------------------------------------------
// HTTP method helpers
// ---------------------------------------------------------------------------
export const api = {
  get: <T = any>(path: string) => request<T>('GET', path),
  post: <T = any>(path: string, body?: unknown) => request<T>('POST', path, body),
  put: <T = any>(path: string, body?: unknown) => request<T>('PUT', path, body),
  patch: <T = any>(path: string, body?: unknown) => request<T>('PATCH', path, body),
  delete: <T = any>(path: string) => request<T>('DELETE', path),
};

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
export const login = (email: string, password: string) =>
  api.post(API_CONFIG.ENDPOINTS.LOGIN, { email, password });

export const forgotPassword = (email: string) =>
  api.post(API_CONFIG.ENDPOINTS.FORGOT_PASSWORD, { email });

export const refreshToken = () =>
  api.post(API_CONFIG.ENDPOINTS.REFRESH_TOKEN, {
    refresh_token: TokenManager.getRefreshToken(),
  });

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------
export const getDashboard = () => api.get(API_CONFIG.ENDPOINTS.DASHBOARD);

// ---------------------------------------------------------------------------
// Products / Inventory
// ---------------------------------------------------------------------------
export const getProducts = (params?: Record<string, string>) => {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return api.get(`${API_CONFIG.ENDPOINTS.PRODUCTS}${qs}`);
};
export const getProduct = (id: number) => api.get(API_CONFIG.ENDPOINTS.PRODUCT(id));
export const createProduct = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.PRODUCTS, data);
export const updateProduct = (id: number, data: unknown) =>
  api.put(API_CONFIG.ENDPOINTS.PRODUCT(id), data);
export const deleteProduct = (id: number) =>
  api.delete(API_CONFIG.ENDPOINTS.PRODUCT(id));

// Stock management
export const stockIn = (data: unknown) => api.post(API_CONFIG.ENDPOINTS.STOCK_IN, data);
export const stockOut = (data: unknown) => api.post(API_CONFIG.ENDPOINTS.STOCK_OUT, data);
export const stockTransfer = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.STOCK_TRANSFER, data);
export const stockAdjustment = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.STOCK_ADJUSTMENT, data);

// ---------------------------------------------------------------------------
// POS / Sales
// ---------------------------------------------------------------------------
export const addToCart = (data: unknown) => api.post(API_CONFIG.ENDPOINTS.CART, data);
export const createSale = (data: unknown) => api.post(API_CONFIG.ENDPOINTS.SALE, data);
export const processPayment = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.PAYMENT, data);

// ---------------------------------------------------------------------------
// Customers
// ---------------------------------------------------------------------------
export const getCustomers = () => api.get(API_CONFIG.ENDPOINTS.CUSTOMERS);
export const createCustomer = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.CUSTOMERS, data);
export const updateCustomer = (id: number, data: unknown) =>
  api.put(API_CONFIG.ENDPOINTS.CUSTOMER(id), data);
export const deleteCustomer = (id: number) =>
  api.delete(API_CONFIG.ENDPOINTS.CUSTOMER(id));

// ---------------------------------------------------------------------------
// Suppliers
// ---------------------------------------------------------------------------
export const getSuppliers = () => api.get(API_CONFIG.ENDPOINTS.SUPPLIERS);
export const createSupplier = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.SUPPLIERS, data);
export const updateSupplier = (id: number, data: unknown) =>
  api.put(API_CONFIG.ENDPOINTS.SUPPLIER(id), data);
export const deleteSupplier = (id: number) =>
  api.delete(API_CONFIG.ENDPOINTS.SUPPLIER(id));

// ---------------------------------------------------------------------------
// Purchases
// ---------------------------------------------------------------------------
export const getPurchases = () => api.get(API_CONFIG.ENDPOINTS.PURCHASES);
export const createPurchase = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.PURCHASES, data);
export const purchasePayment = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.PURCHASE_PAYMENT, data);

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------
export const getReport = (type: string, params?: Record<string, string>) => {
  const qs = params ? '?' + new URLSearchParams(params).toString() : '';
  return api.get(`${API_CONFIG.ENDPOINTS.REPORTS(type)}${qs}`);
};

// ---------------------------------------------------------------------------
// Multi-Store
// ---------------------------------------------------------------------------
export const getStores = () => api.get(API_CONFIG.ENDPOINTS.STORES);
export const switchStore = (storeId: number) =>
  api.post(API_CONFIG.ENDPOINTS.SWITCH_STORE, { store_id: storeId });

// ---------------------------------------------------------------------------
// Subscription
// ---------------------------------------------------------------------------
export const getSubscription = () => api.get(API_CONFIG.ENDPOINTS.SUBSCRIPTION);

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------
export const getNotifications = () => api.get(API_CONFIG.ENDPOINTS.NOTIFICATIONS);

// ---------------------------------------------------------------------------
// Profile
// ---------------------------------------------------------------------------
export const getProfile = () => api.get(API_CONFIG.ENDPOINTS.PROFILE);
export const updateProfile = (data: unknown) =>
  api.put(API_CONFIG.ENDPOINTS.PROFILE, data);
export const changePassword = (data: unknown) =>
  api.post(API_CONFIG.ENDPOINTS.CHANGE_PASSWORD, data);
