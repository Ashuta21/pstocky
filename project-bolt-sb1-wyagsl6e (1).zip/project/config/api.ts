/**
 * PStocky API Configuration
 * Change BASE_URL to point to your PHP/MySQL backend.
 */

export const API_CONFIG = {
  // Replace with your actual server URL. No trailing slash.
  BASE_URL: 'https://yourdomain.com/api',

  // Request timeout in milliseconds
  TIMEOUT: 30000,

  // How many times to retry a failed request
  MAX_RETRIES: 3,

  // Delay (ms) between retries (doubles each attempt)
  RETRY_DELAY: 1000,

  // Token storage key (Expo SecureStore)
  TOKEN_KEY: 'pstocky_jwt_token',
  REFRESH_TOKEN_KEY: 'pstocky_refresh_token',

  // API endpoints
  ENDPOINTS: {
    // Auth
    LOGIN: '/login',
    LOGOUT: '/logout',
    REFRESH_TOKEN: '/refresh-token',
    FORGOT_PASSWORD: '/forgot-password',

    // Dashboard
    DASHBOARD: '/dashboard',

    // Products / Inventory
    PRODUCTS: '/products',
    PRODUCT: (id: number) => `/products/${id}`,
    STOCK_IN: '/stock-in',
    STOCK_OUT: '/stock-out',
    STOCK_TRANSFER: '/stock-transfer',
    STOCK_ADJUSTMENT: '/stock-adjustment',

    // POS / Sales
    CART: '/cart',
    SALE: '/sale',
    PAYMENT: '/payment',

    // Customers
    CUSTOMERS: '/customers',
    CUSTOMER: (id: number) => `/customers/${id}`,

    // Suppliers
    SUPPLIERS: '/suppliers',
    SUPPLIER: (id: number) => `/suppliers/${id}`,

    // Purchases
    PURCHASES: '/purchases',
    PURCHASE_PAYMENT: '/purchase-payment',

    // Reports
    REPORTS: (type: string) => `/reports/${type}`,

    // Multi-Store
    STORES: '/stores',
    SWITCH_STORE: '/switch-store',

    // Subscription
    SUBSCRIPTION: '/subscription',

    // Notifications
    NOTIFICATIONS: '/notifications',

    // Profile
    PROFILE: '/profile',
    CHANGE_PASSWORD: '/change-password',
  },

  // Android FCM config (Firebase Cloud Messaging)
  // Replace with your Firebase project values
  FCM: {
    PROJECT_ID: 'pstocky-app',
    SENDER_ID: '000000000000',
  },
} as const;

export type ApiEndpointKey = keyof typeof API_CONFIG.ENDPOINTS;
